package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.content.DialogInterface;
import android.content.Intent;

public class deleteActivity extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getclubactivity.php";
	private static final String urld = connectIP.IP + "deleteactivity.php";
	
	final static int REQUEST=10;
	
	private TextView deleteactivity_back;
	private ListView deleteactivity_activityList;
	private Button deleteactivity_button;
	
	String CID;
	String clubName;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String UserId = "";
	String result = "";
	String resultd = "";
	String stClub = "";
	String[] AID = new String[100];
	int[] Checked = new int[100];
	int CheckedNum = 0;
	String dString = "";
	String ActivityName;
	String ActivityTime;
	String ActivityEndTime;
	String ActivityTimeTag;
	String ActivityNum;
	String ActivityPlace;
	
	public Bundle bundle_cid = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deleteactivity);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        UserId = bundle.getString("UserId");
        stClub  = bundle.getString("stClub");
        
        findAllView();
        
        getActivityData();
		
        setNewAdapter();
	}
	
	private void findAllView() {
		deleteactivity_back = (TextView) findViewById(R.id.deleteactivity_back);
		deleteactivity_back.setOnClickListener(click_deleteactivity_back);
		
		deleteactivity_activityList = (ListView) findViewById(R.id.deleteactivity_activityList);
		deleteactivity_activityList.setOnItemClickListener(click_deleteactivity_activityList);
		
		deleteactivity_button = (Button) findViewById(R.id.deleteactivity_button);
		deleteactivity_button.setOnClickListener(click_deleteactivity_button);
		
		bundle_cid.putString("UserId", UserId);
		bundle_cid.putString("CID", CID);
		bundle_cid.putString("clubName", clubName);
		bundle_cid.putString("clubType", clubType);
		bundle_cid.putString("clubSubjection", clubSubjection);
		bundle_cid.putString("clubNum", clubNum);
		bundle_cid.putString("QQ", QQ);
		bundle_cid.putString("WeiXin", WeiXin);
		bundle_cid.putString("stClub", stClub);
	}
	
	OnClickListener click_deleteactivity_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnItemClickListener click_deleteactivity_activityList = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		TextView check = (TextView) view.findViewById(R.id.deleteactivity_list_check);
    		if(Checked[position] == 0)
    		{
    			Checked[position] = 1;
    			check.setText("��");
    		}
    		else if(Checked[position] == 1)
    		{
    			Checked[position] = 0;
    			check.setText("");
    		}
		}
    };
    //ɾ���
    OnClickListener click_deleteactivity_button = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		AlertDialog.Builder builder = new Builder(deleteActivity.this);
    		builder.setTitle("���棡");
    		builder.setMessage("�˲����޷���ԭ���Ƿ�ȷ�ϣ�");
    		//�����ȷ�ϰ�ťʱ
    		builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener(){
    			@Override
    			public void onClick(DialogInterface arg0, int arg1) {
    				doDelete();
    				showresult();
    		}
    		});
    		//�����ȡ����ťʱ
    		builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
    			@Override
    			public void onClick(DialogInterface arg0, int arg1) {
    				//nothing to do
    			}
    		});
    		AlertDialog dialog = builder.create();
    		dialog.show();
    	}
    };
    
    private void setNewAdapter()
    {
    	SimpleAdapter adapter = new SimpleAdapter(this,showData(),R.layout.deleteactivity_list,
                new String[]{"deleteactivity_list_activityName",
							 "deleteactivity_list_time",
							 "deleteactivity_list_timeTag"},
                new int[]{
						  R.id.deleteactivity_list_activityName,
						  R.id.deleteactivity_list_time,
						  R.id.deleteactivity_list_timeTag});
        deleteactivity_activityList.setAdapter(adapter);
    }
    
    private List<Map<String,Object>> showData()
    {
    	List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    	Map<String,Object> map;
    	
    	try
		{
			JSONObject jsonObject = new JSONObject(result); 
			JSONArray jsonArray = jsonObject.getJSONArray("activity");
			
			CheckedNum = jsonArray.length();
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				AID[i] = jsonObject2.optString("AID");
				Checked[i] = 0;
				CID = jsonObject2.optString("CID");
				ActivityName = jsonObject2.optString("ActivityName");
				ActivityTime = jsonObject2.optString("ActivityTime");
				ActivityEndTime = jsonObject2.optString("ActivityEndTime");
				ActivityTimeTag = jsonObject2.optString("ActivityTimeTag");
				ActivityNum = jsonObject2.optString("ActivityNum");
				ActivityPlace = jsonObject2.optString("ActivityPlace");
				
				String timeTagString = "";
				
				if(ActivityTimeTag.compareTo("0") == 0)
				{
					timeTagString = "��ȷ��";
				}
				else if(ActivityTimeTag.compareTo("1") == 0)
				{
					timeTagString = "δɸѡ";
				}
				else if(ActivityTimeTag.compareTo("2") == 0)
				{
					timeTagString = "δͶƱ";
				}
				else if(ActivityTimeTag.compareTo("3") == 0)
				{
					timeTagString = "δȷ��";
				}
				
				map = new HashMap<String,Object>();
		    	map.put("deleteactivity_list_activityName" , ActivityName);
		    	map.put("deleteactivity_list_time" , ActivityTime + " - " + ActivityEndTime);
		    	map.put("deleteactivity_list_timeTag" , timeTagString);
		    	list.add(map);
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
    	
    	return list;
    }
    
    public void getActivityData()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("CID", CID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void doDelete() {
    	//����json��
    	dString = "[";
    	for(int i = 0 ; i < CheckedNum ; i++)
    	{
    		if(i != 0)
    		{
    			dString += ",";
    		}
    		dString += "{\"AID\":";
			dString += AID[i];
			dString += ",\"Checked\":";
			dString += Checked[i];
			dString += "}";
    	}
    	dString += "]";
    	dePOST();
    }
    
    public void dePOST()
    {
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("dString", dString));
		            HttpPost httpRequest = new HttpPost(urld);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	resultd = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"resultd = "+resultd);
		            }
		            else
		            {
		            	//
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void showresult()
    {
    	if(resultd.compareTo("1") == 0)
    	{
    		Toast.makeText(deleteActivity.this, "ɾ���ɹ�",Toast.LENGTH_LONG ).show();
    		getActivityData();
	        setNewAdapter();
    	}
    	else
    	{
    		Toast.makeText(deleteActivity.this, resultd ,Toast.LENGTH_LONG ).show();
    	}
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
}