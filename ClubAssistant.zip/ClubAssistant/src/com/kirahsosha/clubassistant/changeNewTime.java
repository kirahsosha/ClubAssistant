package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class changeNewTime extends Activity {
	
	private static final String TAG = "jby";
	
	final static int REQUEST=10;
	
	private TimePicker changenewtime_startTime;
	private TimePicker changenewtime_endTime;
	private Button changenewtime_buttonBack;
	private Button changenewtime_buttonEnter;
	
	String CID;
	String UserId;
	String ActivityName;
	String ActivityNum;
	String ActivityPlace;
	int year , month , day;
	String clubName;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String timeJson = "";
	String newTimeJson = "";
	String newStartTime;
	String newEndTime;
	String startTime[] = new String[100];
	String endTime[] = new String[100];
	
	public Bundle bundle_new = new Bundle();
	
	String enableStartTime = "";
	String enableEndTime = "";
	String enableTime = "";
	String stClub = "";
	
	int startHour;
	int startMinute;
	int endHour;
	int endMinute;
	int iStartTime , iEndTime;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changenewtime);
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        UserId = bundle.getString("UserId");
        year = bundle.getInt("year");
        month = bundle.getInt("month");
        day = bundle.getInt("day");
        ActivityName = bundle.getString("ActivityName");
        ActivityNum = bundle.getString("ActivityNum");
        ActivityPlace = bundle.getString("ActivityPlace");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        stClub  = bundle.getString("stClub");
        timeJson  = bundle.getString("timeJson");	//�Ѿ���jsonͷ�Ĵ�
        newStartTime  = bundle.getString("newStartTime");
        newEndTime  = bundle.getString("newEndTime");
        newTimeJson = timeJson + "]";
        
        findAllView();
        setChangedTime();
	}
	
	private void findAllView(){
		changenewtime_startTime = (TimePicker) findViewById(R.id.changenewtime_startTime);
		changenewtime_endTime = (TimePicker) findViewById(R.id.changenewtime_endTime);
		changenewtime_startTime.setIs24HourView(true);
		changenewtime_endTime.setIs24HourView(true);
		
		changenewtime_buttonBack = (Button) findViewById(R.id.changenewtime_buttonBack);
		changenewtime_buttonBack.setOnClickListener(click_changenewtime_buttonBack);
		
		changenewtime_buttonEnter = (Button) findViewById(R.id.changenewtime_buttonEnter);
		changenewtime_buttonEnter.setOnClickListener(click_changenewtime_buttonEnter);
		
		bundle_new.putString("UserId", UserId);
		bundle_new.putString("CID", CID);
		bundle_new.putInt("year", year);
		bundle_new.putInt("month", month);
		bundle_new.putInt("day", day);
		bundle_new.putString("ActivityName", ActivityName);
		bundle_new.putString("ActivityNum", ActivityNum);
		bundle_new.putString("ActivityPlace", ActivityPlace);
		bundle_new.putString("clubName", clubName);
		bundle_new.putString("clubType", clubType);
		bundle_new.putString("clubSubjection", clubSubjection);
		bundle_new.putString("clubNum", clubNum);
		bundle_new.putString("QQ", QQ);
		bundle_new.putString("WeiXin", WeiXin);
		bundle_new.putString("stClub", stClub);
	}
	
	OnClickListener click_changenewtime_buttonBack = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_changenewtime_buttonEnter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		startHour = changenewtime_startTime.getCurrentHour();
        	startMinute = changenewtime_startTime.getCurrentMinute();
        	endHour = changenewtime_endTime.getCurrentHour();
        	endMinute = changenewtime_endTime.getCurrentMinute();
        	
        	iStartTime = timeTax(startHour , startMinute);
        	iEndTime = timeTax(endHour , endMinute);
        	//�жϽ���ʱ���Ƿ��ڿ�ʼʱ��֮��
        	if(iEndTime > iStartTime)
        	{
        		timeJson = setTimeJson();
        		bundle_new.putString("timeJson", timeJson);
        		Toast.makeText(changeNewTime.this, "ʱ���޸ĳɹ�", Toast.LENGTH_LONG ).show();
        		Intent it = new Intent(changeNewTime.this , newActivityTime.class);
            	it.putExtras(bundle_new);
    	    	if (it != null){
    				startActivityForResult(it,REQUEST);
    			}
        	}
        	else
        	{
        		Toast.makeText(changeNewTime.this, "�����ʱ������ڿ�ʼʱ��֮��",Toast.LENGTH_LONG ).show();
        	}
    	}
    };
    
    //�ж��Ƿ񴴽��»
    //����ֵ
    //0 - NULL
    //1 - ����ʱ�䲻�ڿ�ʼʱ��֮��
    //2 - �ʱ�䲻��������Χ֮��
    //3 - ���Դ���
	private String setTimeJson()
	{
    	String newJson = "";
    	String startTimeJson = "";
    	String endTimeJson = "";
    	int kkk = 0 , timeNum = 0;
    	
    	//����json�����޸�ʱ��
    	JSONArray jsonArray;
		try {
			jsonArray = new JSONArray(newTimeJson);
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject = jsonArray.optJSONObject(i);
				startTime[i] = jsonObject.optString("start");
				endTime[i] = jsonObject.optString("end");
				if(startTime[i] == newStartTime && endTime[i] == newEndTime && kkk == 0)
				{
					kkk = 1;
					if(startHour < 10)
			    	{
			    		startTimeJson = "0" + startHour + ":";
			    	}
			    	else
			    	{
			    		startTimeJson = startHour + ":";
			    	}
			    	
			    	if(startMinute < 10)
			    	{
			    		startTimeJson = startTimeJson + "0" + startMinute + ":00";
			    	}
			    	else
			    	{
			    		startTimeJson = startTimeJson + startMinute + ":00";
			    	}
			    	
			    	if(endHour < 10)
			    	{
			    		endTimeJson = "0" + endHour + ":";
			    	}
			    	else
			    	{
			    		endTimeJson = endHour + ":";
			    	}
			    	
			    	if(endMinute < 10)
			    	{
			    		endTimeJson = endTimeJson + "0" + endMinute + ":00";
			    	}
			    	else
			    	{
			    		endTimeJson = endTimeJson + endMinute + ":00";
			    	}
			    	startTime[i] = startTimeJson;
			    	endTime[i] = endTimeJson;
				}
			}
			timeNum = jsonArray.length();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//����json��
		newJson = "[\"newTimeJson\":";
		for(int i = 0 ; i < timeNum ; i++)
		{
			if(i != 0)
			{
				newJson += ",";
			}
			newJson += "{\"start\":\"" + startTime[i] + "\",\"end\":\"" + endTime[i] + "\"}";
		}
    	return newJson;
    }
    
    //ת��������
    private int timeTax(int h , int m)
    {
    	return h * 60 + m;
    }
    
    private void setChangedTime()
    {
    	int startChangedHour , startChangedMinute;
    	int endChangedHour , endChangedMinute;
    	startChangedHour = Integer.parseInt(newStartTime.substring(0 , 2));
    	startChangedMinute = Integer.parseInt(newStartTime.substring(3 , 5));
    	endChangedHour = Integer.parseInt(newEndTime.substring(0 , 2));
    	endChangedMinute = Integer.parseInt(newEndTime.substring(3 , 5));
    	changenewtime_startTime.setCurrentHour(startChangedHour);
    	changenewtime_startTime.setCurrentMinute(startChangedMinute);
    	changenewtime_endTime.setCurrentHour(endChangedHour);
    	changenewtime_endTime.setCurrentMinute(endChangedMinute);
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
}