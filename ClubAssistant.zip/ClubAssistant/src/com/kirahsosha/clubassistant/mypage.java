package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.R.integer;
import android.os.Bundle;
import android.app.Activity;
import android.text.format.Time;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.content.Intent;

public class mypage extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "mypage.php";
	
	final static int REQUEST=10;
	
	private TextView mypage_back;
	private TextView mypage_setup;
	private RelativeLayout mypage_activityManage;
	private RelativeLayout mypage_clubManage;
	private RelativeLayout mypage_scheduleManage;
	private TextView mypage_activityManageNum;
	
	//���ݴ洢
	
	//����Ϣ����
	String UserId;
	
	//��Ŀ��
	public int activity_tomo = 0;
	public int activity_undo = 0;
	public int activity_done = 0;
	
	public Bundle bundle_activity = new Bundle();
	public Bundle bundle_club = new Bundle();
	public Bundle bundle_uid = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mypage);
        Bundle bundle = this.getIntent().getExtras();
        UserId  = bundle.getString("UserId");
        Log.v(TAG, UserId);
        findAllView();
    	
        getData();
    }
	
	//��������
    private void findAllView(){
    	mypage_back = (TextView) findViewById(R.id.mypage_back);
    	mypage_back.setOnClickListener(click_mypage_back);
    	
    	mypage_setup = (TextView) findViewById(R.id.mypage_setup);
    	mypage_setup.setOnClickListener(click_mypage_setup);
    	
    	mypage_activityManage = (RelativeLayout) findViewById(R.id.mypage_activityManage);
    	mypage_activityManage.setOnClickListener(click_mypage_activityManage);
    	
    	mypage_clubManage = (RelativeLayout) findViewById(R.id.mypage_clubManage);
    	mypage_clubManage.setOnClickListener(click_mypage_clubManage);
    	
    	mypage_scheduleManage = (RelativeLayout) findViewById(R.id.mypage_scheduleManage);
    	mypage_scheduleManage.setOnClickListener(click_mypage_scheduleManage);
    	
    	mypage_activityManageNum = (TextView) findViewById(R.id.mypage_activityManageNum);
    	
    	bundle_activity.putString("UserId", UserId);
    	bundle_club.putString("UserId", UserId);
    	bundle_uid.putString("UserId", UserId);
    }
    
    OnClickListener click_mypage_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    //�����
    OnClickListener click_mypage_activityManage = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(mypage.this , activityManage.class);
    		it.putExtras(bundle_activity);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    //���Ź���
    OnClickListener click_mypage_clubManage = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(mypage.this , clubList.class);
    		it.putExtras(bundle_club);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    //����
    OnClickListener click_mypage_setup = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(mypage.this , userManage.class);
    		it.putExtras(bundle_uid);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    OnClickListener click_mypage_scheduleManage = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(mypage.this , scheduleManage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
	public void getData()
    {
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("userid", UserId));
		            HttpPost httpRequest = new HttpPost(url);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	String result = EntityUtils.toString(httpResponse.getEntity());
		            	saveData(result);
		                //Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	//��json�л�ȡ����
	public void saveData(String jString)
	{
		//user
		try
		{
			JSONObject jsonObject = new JSONObject(jString); 
			JSONArray jsonArray = jsonObject.getJSONArray("user");
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				String UID = jsonObject2.optString("UID");
				String UserId = jsonObject2.optString("UserId");
				String UserPWD = jsonObject2.optString("UserPWD");
				String UserName = jsonObject2.optString("UserName");
				String UserSex = jsonObject2.optString("UserSex");
				String UserAge = jsonObject2.optString("UserAge");
				Log.v(TAG, "i = " + Integer.toString(i));
				Log.v(TAG, UID);
				Log.v(TAG, UserId);
				Log.v(TAG, UserPWD);
				Log.v(TAG, UserName);
				Log.v(TAG, UserSex);
				Log.v(TAG, UserAge);
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
		
		//club
		try
		{
			JSONObject jsonObject = new JSONObject(jString); 
			JSONArray jsonArray = jsonObject.optJSONArray("club");
			String stClub = "";
			Log.v(TAG,Integer.toString(jsonArray.length()));
			stClub = jsonArray.toString();
			Log.v(TAG, "stClub = " + stClub);
			bundle_club.putString("stClub", stClub);
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				String CID = jsonObject2.optString("CID");
				String ClubName = jsonObject2.optString("ClubName");
				String ClubType = jsonObject2.optString("ClubType");
				String ClubSubjection = jsonObject2.optString("ClubSubjection");
				String ClubNum = jsonObject2.optString("ClubNum");
				String ClubQQ = jsonObject2.optString("ClubQQ");
				String ClubWeiXin = jsonObject2.optString("ClubWeiXin");
				Log.v(TAG, "i = " + Integer.toString(i));
				Log.v(TAG, CID);
				Log.v(TAG, ClubName);
				Log.v(TAG, ClubType);
				Log.v(TAG, ClubSubjection);
				Log.v(TAG, ClubNum);
				Log.v(TAG, ClubQQ);
				Log.v(TAG, ClubWeiXin);
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
		
		//activity
		try
		{
			JSONObject jsonObject = new JSONObject(jString); 
			JSONArray jsonArray = jsonObject.getJSONArray("activity");
			
			String stTomo = "[";
			String stUndo = "[";
			String stDone = "[";
			String stAll = "";
			stAll = jsonArray.toString();
			bundle_activity.putString("stAll", stAll);
			int activity_num = jsonArray.length();
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				String AID = jsonObject2.optString("AID");
				String CID = jsonObject2.optString("CID");
				String ActivityName = jsonObject2.optString("ActivityName");
				String ActivityTime = jsonObject2.optString("ActivityTime");
				String ActivityNum = jsonObject2.optString("ActivityNum");
				String ActivityPlace = jsonObject2.optString("ActivityPlace");
				Log.v(TAG, "i = " + Integer.toString(i));
				Log.v(TAG, AID);
				Log.v(TAG, CID);
				Log.v(TAG, ActivityName);
				Log.v(TAG, ActivityTime);
				Log.v(TAG, ActivityNum);
				Log.v(TAG, ActivityPlace);
				
				//��ȡ��������ǰʱ����ʱ�䲢�Ƚ�
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		    	String date = sdf.format(new java.util.Date());
		    	Date d1 = sdf.parse(date);
		    	int yearNow = Integer.parseInt(date.substring(0,4));
		    	int monthNow = Integer.parseInt(date.substring(5,7));
		    	int dayNow = Integer.parseInt(date.substring(8,10));
		    	Log.v(TAG, "date : " + date);
		    	Log.v(TAG, "yearNow : " + yearNow);
		    	Log.v(TAG, "monthNow : " + monthNow);
		    	Log.v(TAG, "dayNow : " + dayNow);
		    	
		    	Date d2 = sdf.parse(ActivityTime);
				int yearActivity = Integer.parseInt(ActivityTime.substring(0,4));
		    	int monthActivity = Integer.parseInt(ActivityTime.substring(5,7));
		    	int dayActivity = Integer.parseInt(ActivityTime.substring(8,10));
		    	Log.v(TAG, "yearActivity : " + yearActivity);
		    	Log.v(TAG, "monthActivity : " + monthActivity);
		    	Log.v(TAG, "dayActivity : " + dayActivity);
		    	
		    	//���ջ��
		    	if(yearNow == yearActivity && monthNow == monthActivity && dayNow == dayActivity - 1)
		    	{
		    		activity_tomo ++;
		    		if(activity_tomo > 1)
		    		{
		    			stTomo = stTomo.concat(",");
		    		}
		    		stTomo = stTomo.concat(jsonObject2.toString());
		    	}
		    	long diff = d1.getTime() - d2.getTime();
		    	//δ��ɻ��
		    	if(diff <= 0)
		    	{
		    		activity_undo ++;
		    		if(activity_undo > 1)
		    		{
		    			stUndo = stUndo.concat(",");
		    		}
		    		stUndo = stUndo.concat(jsonObject2.toString());
		    	}
		    	//����ɻ��
		    	if(diff > 0)
		    	{
		    		activity_done ++;
		    		if(activity_done > 1)
		    		{
		    			stDone = stDone.concat(",");
		    		}
		    		stDone = stDone.concat(jsonObject2.toString());
		    	}
			}
			mypage_activityManageNum.setText(Integer.toString(activity_num));
			stTomo = stTomo.concat("]");
			stUndo = stUndo.concat("]");
			stDone = stDone.concat("]");
			bundle_activity.putString("stTomo", stTomo);
			bundle_activity.putString("stUndo", stUndo);
			bundle_activity.putString("stDone", stDone);
			Log.v(TAG, "stTomo = " + stTomo);
			Log.v(TAG, "stUndo = " + stUndo);
			Log.v(TAG, "stDone = " + stDone);
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
	}
}