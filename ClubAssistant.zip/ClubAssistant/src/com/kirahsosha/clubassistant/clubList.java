package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class clubList extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "searchclub.php";
	
	final static int REQUEST=10;
	
	private TextView clublist_back;
	private TextView clublist_viewMy;
	private ListView clublist_clubList;
	private TextView clublist_searchText;
	private TextView clublist_myListText;
	private EditText clublist_searchEdit;
	
	public String stClub = "";
	public String[] CID = new String[100];
	public Bundle bundle_inf = new Bundle();
	public Bundle bundle_uid = new Bundle();
	String UserId = "";
	
	String result;
	String searchText;
	String clubText = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clublist);
        
        Bundle bundle = this.getIntent().getExtras();
        stClub  = bundle.getString("stClub");
        UserId = bundle.getString("UserId");
        clubText = stClub;
        
        findAllView();
        
        setNewAdapter();
    }
	
	private void findAllView(){
		clublist_back = (TextView) findViewById(R.id.clublist_back);
		clublist_back.setOnClickListener(click_clublist_back);
		
		clublist_viewMy = (TextView) findViewById(R.id.clublist_viewMy);
		clublist_viewMy.setOnClickListener(click_clublist_viewMy);
		
		clublist_clubList = (ListView) findViewById(R.id.clublist_clubList);
		clublist_clubList.setOnItemClickListener(click_clublist_clubList);
		
		clublist_searchText = (TextView) findViewById(R.id.clublist_searchText);
		clublist_searchText.setOnClickListener(click_clublist_searchText);
		
		clublist_myListText = (TextView) findViewById(R.id.clublist_myListText);
		clublist_myListText.setOnClickListener(click_clublist_myListText);
		
		clublist_searchEdit = (EditText) findViewById(R.id.clublist_searchEdit);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("stClub", stClub);
		bundle_uid.putString("UserId", UserId);
	}
	
	OnClickListener click_clublist_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_clublist_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubList.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnItemClickListener click_clublist_clubList = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		
    		TextView clubName= (TextView) view.findViewById(R.id.clublist_list_clubName);
    		TextView clubType= (TextView) view.findViewById(R.id.clublist_list_clubType);
    		TextView clubSubjection= (TextView) view.findViewById(R.id.clublist_list_clubSubjection);
    		TextView clubNum= (TextView) view.findViewById(R.id.clublist_list_clubNum);
    		TextView clubQQ= (TextView) view.findViewById(R.id.clublist_list_QQ);
    		TextView clubWeiXin= (TextView) view.findViewById(R.id.clublist_list_WeiXin);
    		bundle_inf.putString("CID", CID[position]);
    		bundle_inf.putString("clubName", clubName.getText().toString());
			bundle_inf.putString("clubType", clubType.getText().toString());
			bundle_inf.putString("clubSubjection", clubSubjection.getText().toString());
			bundle_inf.putString("clubNum", clubNum.getText().toString());
			bundle_inf.putString("QQ", clubQQ.getText().toString());
			bundle_inf.putString("WeiXin", clubWeiXin.getText().toString());
			
    		Intent it = new Intent(clubList.this, clubInf.class);
    		it.putExtras(bundle_inf);
    		if (it != null){
				startActivityForResult(it,REQUEST);
			}
		}
    };
    
    OnClickListener click_clublist_searchText = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		searchText = clublist_searchEdit.getText().toString();
    		searchClub();
    		clubText = result;
    		setNewAdapter();
    	}
    };
    
    OnClickListener click_clublist_myListText = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		clubText = stClub;
    		setNewAdapter();
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    private void setNewAdapter()
    {
    	SimpleAdapter adapter = new SimpleAdapter(this,showData(),R.layout.clublist_list,
                new String[]{"clublist_list_clubName",
							 "clublist_list_clubType",
							 "clublist_list_clubSubjection",
							 "clublist_list_clubNum",
							 "clublist_list_QQ",
							 "clublist_list_WeiXin"},
                new int[]{
						  R.id.clublist_list_clubName,
						  R.id.clublist_list_clubType,
						  R.id.clublist_list_clubSubjection,
						  R.id.clublist_list_clubNum,
						  R.id.clublist_list_QQ,
						  R.id.clublist_list_WeiXin});
        clublist_clubList.setAdapter(adapter);
    }
    
    private List<Map<String,Object>> showData()
    {
    	try
    	{
    		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    		JSONArray jsonArray = new JSONArray(clubText);
    		for(int i = 0 ; i < jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject = jsonArray.optJSONObject(i);
    			CID[i] = jsonObject.optString("CID");
    			String ClubName = jsonObject.optString("ClubName");
    			String ClubType = jsonObject.optString("ClubType");
    			String ClubSubjection = jsonObject.optString("ClubSubjection");
    			String ClubNum = jsonObject.optString("ClubNum");
    			String ClubQQ = jsonObject.optString("ClubQQ");
    			String ClubWeiXin = jsonObject.optString("ClubWeiXin");
    			
    	    	Map<String,Object> map = new HashMap<String,Object>();
    	    	map.put("clublist_list_clubName",ClubName);
    	    	map.put("clublist_list_clubType",ClubType);
    	    	map.put("clublist_list_clubSubjection",ClubSubjection);
    	    	map.put("clublist_list_clubNum",ClubNum);
    	    	map.put("clublist_list_QQ",ClubQQ);
    	    	map.put("clublist_list_WeiXin",ClubWeiXin);
    	    	list.add(map);
    		}
    		return list;
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
			return null;
		}
    }
    
    public void searchClub()
    {
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("searchText", searchText));
		            HttpPost httpRequest = new HttpPost(url);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                //Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}