package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class setNewSelectTime extends Activity {
	
	private static final String TAG = "jby";
	
	final static int REQUEST=10;
	
	private TextView setnewselecttime_enableTime;
	private TextView setnewselecttime_date;
	private TimePicker setnewselecttime_startTime;
	private TimePicker setnewselecttime_endTime;
	private Button setnewselecttime_buttonBack;
	private Button setnewselecttime_buttonEnter;
	
	String AID;
	String UserId;
	String clubName;
	String timeResult;
	String dateString;
	
	public Bundle bundle_inf = new Bundle();
	
	String enableStartTime = "";
	String enableEndTime = "";
	String enableTime = "";
	String stClub = "";
	
	int startHour;
	int startMinute;
	int endHour;
	int endMinute;
	int iStartTime , iEndTime;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setnewselecttime);
        
        Bundle bundle = this.getIntent().getExtras();
        AID  = bundle.getString("AID");
        UserId = bundle.getString("UserId");
        clubName = bundle.getString("clubName");
        timeResult = bundle.getString("timeResult");
        dateString = bundle.getString("dateString");
        Log.v(TAG, "date = " + dateString);
        findAllView();
	}
	
	private void findAllView(){
		setnewselecttime_startTime = (TimePicker) findViewById(R.id.setnewselecttime_startTime);
		setnewselecttime_endTime = (TimePicker) findViewById(R.id.setnewselecttime_endTime);
		setnewselecttime_startTime.setIs24HourView(true);
		setnewselecttime_endTime.setIs24HourView(true);
		
		setnewselecttime_buttonBack = (Button) findViewById(R.id.setnewselecttime_buttonBack);
		setnewselecttime_buttonBack.setOnClickListener(click_setnewselecttime_buttonBack);
		
		setnewselecttime_buttonEnter = (Button) findViewById(R.id.setnewselecttime_buttonEnter);
		setnewselecttime_buttonEnter.setOnClickListener(click_setnewselecttime_buttonEnter);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("AID", AID);
		bundle_inf.putString("clubName", clubName);
	}
	
	OnClickListener click_setnewselecttime_buttonBack = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_setnewselecttime_buttonEnter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		startHour = setnewselecttime_startTime.getCurrentHour();
        	startMinute = setnewselecttime_startTime.getCurrentMinute();
        	endHour = setnewselecttime_endTime.getCurrentHour();
        	endMinute = setnewselecttime_endTime.getCurrentMinute();
        	
        	iStartTime = timeTax(startHour , startMinute);
        	iEndTime = timeTax(endHour , endMinute);
        	//�жϽ���ʱ���Ƿ��ڿ�ʼʱ��֮��
        	if(iEndTime > iStartTime)
        	{
        		timeResult = setTimeResult();
        		bundle_inf.putString("result", timeResult);
        		Toast.makeText(setNewSelectTime.this, "��ʱ�䴴���ɹ�", Toast.LENGTH_LONG ).show();
        		Intent it = new Intent(setNewSelectTime.this , timeSelect1.class);
            	it.putExtras(bundle_inf);
    	    	if (it != null){
    				startActivityForResult(it,REQUEST);
    			}
        	}
        	else
        	{
        		Toast.makeText(setNewSelectTime.this, "�����ʱ������ڿ�ʼʱ��֮��",Toast.LENGTH_LONG ).show();
        	}
    	}
    };
    
    //�ж��Ƿ񴴽��»
    //����ֵ
    //0 - NULL
    //1 - ����ʱ�䲻�ڿ�ʼʱ��֮��
    //2 - �ʱ�䲻��������Χ֮��
    //3 - ���Դ���
	private String setTimeResult()
	{
    	String newJson = "";
    	String startTimeJson = dateString + " ";
    	String endTimeJson = dateString + " ";
    	
    	if(startHour < 10)
    	{
    		startTimeJson += "0" + startHour + ":";
    	}
    	else
    	{
    		startTimeJson += startHour + ":";
    	}
    	
    	if(startMinute < 10)
    	{
    		startTimeJson = startTimeJson + "0" + startMinute + ":00";
    	}
    	else
    	{
    		startTimeJson = startTimeJson + startMinute + ":00";
    	}
    	
    	if(endHour < 10)
    	{
    		endTimeJson += "0" + endHour + ":";
    	}
    	else
    	{
    		endTimeJson += endHour + ":";
    	}
    	
    	if(endMinute < 10)
    	{
    		endTimeJson = endTimeJson + "0" + endMinute + ":00";
    	}
    	else
    	{
    		endTimeJson = endTimeJson + endMinute + ":00";
    	}
    	
    	if(timeResult.compareTo("[") != 0)
    	{
    		timeResult = timeResult.substring(0 , timeResult.length()-1);
    		timeResult += ",";
    	}
    	newJson = timeResult + "{\"ATID\": \"" + 0 + "\",\"StartTime\": \"" + startTimeJson + "\",\"EndTime\": \"" + endTimeJson + "\",\"TimeTag\": \"" + 1 + "\"}]";
    	return newJson;
    }
    
    //ת��������
    private int timeTax(int h , int m)
    {
    	return h * 60 + m;
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
}