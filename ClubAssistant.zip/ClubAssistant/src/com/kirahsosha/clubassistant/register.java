package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;

public class register extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "register.php";
	
	final static int REQUEST=10;
	
	private EditText register_UserId;
	private EditText register_Password;
	private EditText register_Password_Re;
	private EditText register_UserName;
	private RadioGroup register_Sex;
	private EditText register_Age;
	private Button register_buttonRegister;
	private Button register_buttonBack;
	
	private String textUserId;
	private String textPassword;
	private String textPassword_Re;
	private String textUserName;
	private String textSex;
	private String textAge;
	
	private String result;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        
        findAllView();
		
		//getData();
    }
	
	private void findAllView()
    {
		register_UserId = (EditText) findViewById(R.id.register_UserId);
		register_Password = (EditText) findViewById(R.id.register_Password);
		register_Password_Re = (EditText) findViewById(R.id.register_Password_Re);
		register_UserName = (EditText) findViewById(R.id.register_UserName);
		register_Sex = (RadioGroup) findViewById(R.id.register_groupSex);
		register_Sex.setOnCheckedChangeListener(click_register_Sex);
		register_Age = (EditText) findViewById(R.id.register_Age);
        
		register_buttonRegister = (Button)findViewById(R.id.register_buttonRegister);
        register_buttonRegister.setOnClickListener(click_register_buttonRegister);
        
        register_buttonBack = (Button)findViewById(R.id.register_buttonBack);
        register_buttonBack.setOnClickListener(click_register_buttonBack);
    }
	
	OnCheckedChangeListener click_register_Sex = new OnCheckedChangeListener(){
		@Override
		public void onCheckedChanged(RadioGroup arg0, int arg1) {
		//��ȡ������ѡ�����ID
		int radioButtonId = arg0.getCheckedRadioButtonId();
		//����ID��ȡRadioButton��ʵ��
		RadioButton sex = (RadioButton) findViewById(radioButtonId);
		Log.v(TAG, sex.getHint().toString());
		textSex = sex.getHint().toString();
		}
	};
	
	OnClickListener click_register_buttonRegister = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		textUserId = register_UserId.getText().toString();
    		textPassword = register_Password.getText().toString();
    		textPassword_Re = register_Password_Re.getText().toString();
    		textUserName = register_UserName.getText().toString();
    		textAge = register_Age.getText().toString();
    		Log.v(TAG, textUserId);
    		Log.v(TAG, textPassword);
    		Log.v(TAG, textUserName);
    		Log.v(TAG, textSex);
    		Log.v(TAG, textAge);
    		if(textPassword.equals(textPassword_Re)) //��������������ͬ�ſ���ע��
    		{
    			toRegister();
        		if(result.compareTo("1") == 0)
                {
                	Log.v(TAG,"Register Success");
                	Toast.makeText(register.this, "ע��ɹ�", Toast.LENGTH_LONG ).show();
                	Bundle bundle = new Bundle();
                	bundle.putString("UserId", textUserId);
                	Intent it = new Intent(register.this , mypage.class);
                	it.putExtras(bundle);
        	    	if (it != null){
        				startActivityForResult(it,REQUEST);
        			}
                }
                else if(result.compareTo("2") == 0)
                {
                	Toast.makeText(register.this, "���ʺ��Ѵ���",Toast.LENGTH_LONG ).show();
                	Log.v(TAG,"Error" + result);
                }
                else
                {
                	Toast.makeText(register.this, "Error:" + result, Toast.LENGTH_LONG ).show();
                }
    		}
    		else
    		{
    			Toast.makeText(register.this, "ȷ�����������������������",Toast.LENGTH_LONG ).show();
    		}
    	}
    };
    
	OnClickListener click_register_buttonBack = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    public void toRegister()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", textUserId));
		            params.add(new BasicNameValuePair("UserPWD", textPassword));
		            params.add(new BasicNameValuePair("UserName", textUserName));
		            params.add(new BasicNameValuePair("UserSex", textSex));
		            params.add(new BasicNameValuePair("UserAge", textAge));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
						Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}