package com.kirahsosha.clubassistant;

import java.util.Calendar;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class newActivityInf extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getclubactivity.php";
	
	final static int REQUEST=10;
	
	private EditText newactivityinf_activityName;
	private EditText newactivityinf_activityNum;
	private EditText newactivityinf_activityPlace;
	private DatePicker newactivityinf_datePicker;
	private Button newactivityinf_buttonBack;
	private Button newactivityinf_buttonNext;
	
	Calendar calendar;
	int year , monthOfYear , dayOfMonth;
	
	String CID;
	String UserId;
	String ActivityName;
	String ActivityNum;
	String ActivityPlace;
	String clubName;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String timeJson = "";
	
	public Bundle bundle_inf = new Bundle();
	String stClub = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newactivityinf);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        UserId = bundle.getString("UserId");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        stClub  = bundle.getString("stClub");
        
        findAllView();
        
        getDate();
        
        initalizeJson();
        bundle_inf.putString("timeJson", timeJson);
	}
	
	private void findAllView(){
		newactivityinf_activityName = (EditText) findViewById(R.id.newactivityinf_activityName);
		newactivityinf_activityNum = (EditText) findViewById(R.id.newactivityinf_activityNum);
		newactivityinf_activityPlace = (EditText) findViewById(R.id.newactivityinf_activityPlace);
		
		newactivityinf_datePicker = (DatePicker) findViewById(R.id.newactivityinf_datePicker);
        
		newactivityinf_buttonBack = (Button) findViewById(R.id.newactivityinf_buttonBack);
		newactivityinf_buttonBack.setOnClickListener(click_newactivityinf_buttonBack);
		
		newactivityinf_buttonNext = (Button) findViewById(R.id.newactivityinf_buttonNext);
		newactivityinf_buttonNext.setOnClickListener(click_newactivityinf_buttonNext);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("CID", CID);
		bundle_inf.putString("clubName", clubName);
		bundle_inf.putString("clubType", clubType);
		bundle_inf.putString("clubSubjection", clubSubjection);
		bundle_inf.putString("clubNum", clubNum);
		bundle_inf.putString("QQ", QQ);
		bundle_inf.putString("WeiXin", WeiXin);
		bundle_inf.putString("stClub", stClub);
	}
	
	private void getDate()
	{
		calendar = Calendar.getInstance();
	    year = calendar.get(Calendar.YEAR);
	    monthOfYear = calendar.get(Calendar.MONTH);
	    dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
	    newactivityinf_datePicker.init(year , monthOfYear , dayOfMonth , new OnDateChangedListener(){

	        public void onDateChanged(DatePicker view , int year , int monthOfYear , int dayOfMonth) {
	        	bundle_inf.putInt("year", year);
	        	bundle_inf.putInt("month", monthOfYear + 1);
	        	bundle_inf.putInt("day", dayOfMonth);
	        	Log.v(TAG, year + "-" + monthOfYear + "-" + dayOfMonth);
	        }
	        
	    });
	}
	
	OnClickListener click_newactivityinf_buttonBack = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_newactivityinf_buttonNext = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(newActivityInf.this , newActivityTime.class);
    		ActivityName = newactivityinf_activityName.getText().toString();
    		ActivityNum = newactivityinf_activityNum.getText().toString();
    		ActivityPlace = newactivityinf_activityPlace.getText().toString();
    		bundle_inf.putString("ActivityName", ActivityName);
    		bundle_inf.putString("ActivityNum", ActivityNum);
    		bundle_inf.putString("ActivityPlace", ActivityPlace);
    		it.putExtras(bundle_inf);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    private void initalizeJson()
    {
    	timeJson = "[";
    	Log.v(TAG , timeJson);
    }
}