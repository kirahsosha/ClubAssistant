package com.kirahsosha.clubassistant;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Calendar.calendarPagerAdapter;
import com.kirahsosha.Calendar.dateFormatter;
import com.kirahsosha.Calendar.lunarCalendar;

import android.os.Bundle;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.DatePicker;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.content.Intent;

public class scheduleManage2 extends FragmentActivity implements
OnDateSetListener, OnMenuItemClickListener, OnFocusChangeListener {
	
	private static final String TAG = "jby";
	
	final static int REQUEST=10;
	
	private TextView schedulemanage2_back;
	private TextView schedulemanage2_viewMy;
	private ListView schedulemanage2_list;
	
	private PagerAdapter mPagerAdapter;
	private View schedulemanage2_imgPreviousMonth, schedulemanage2_imgNextMonth;
	private dateFormatter formatter;

	private TextView schedulemanage2_textTitleMonth, schedulemanage2_txtTitleAddition, schedulemanage2_txtTitleLunar;
	
	public Bundle bundle_date = new Bundle();
	public Bundle bundle_uid = new Bundle();
	String UserId = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedulemanage2);
        Log.v(TAG, "setContentView(R.layout.schedulemanage);");
        
        Bundle bundle = this.getIntent().getExtras();
        Log.v(TAG, "Bundle bundle = this.getIntent().getExtras();");
        UserId = bundle.getString("UserId");
        Log.v(TAG, "UserId = bundle.getString('UserId');");
        
        findAllView();
        Log.v(TAG, "findAllView();");
        
        SimpleAdapter adapter = new SimpleAdapter(this,showData(),R.layout.schedulemanage2_list,
                new String[]{"textViewForText"},
                new int[]{R.id.textViewForText});
        schedulemanage2_list.setAdapter(adapter);
    }
	
	private void findAllView(){
		formatter = new dateFormatter(this.getResources());
		Log.v(TAG, "formatter = new dateFormatter(this.getResources());");

        schedulemanage2_imgPreviousMonth = findViewById(R.id.schedulemanage2_imgPreviousMonth);
        Log.v(TAG, "schedulemanage2_imgPreviousMonth");
        schedulemanage2_imgNextMonth = findViewById(R.id.schedulemanage2_imgNextMonth);
        Log.v(TAG, "schedulemanage2_imgNextMonth");
        schedulemanage2_textTitleMonth = (TextView) findViewById(R.id.schedulemanage2_textTitleMonth);
        schedulemanage2_textTitleMonth.setText("24��");
        Log.v(TAG, "schedulemanage2_textTitleMonth");
        schedulemanage2_txtTitleAddition = (TextView) findViewById(R.id.schedulemanage2_txtTitleAddition);
        schedulemanage2_txtTitleAddition.setText("2016/06/12 - 2016/06/18");
        Log.v(TAG, "schedulemanage2_txtTitleAddition");
        schedulemanage2_txtTitleLunar = (TextView) findViewById(R.id.schedulemanage2_txtTitleLunar);
        Log.v(TAG, "schedulemanage2_txtTitleLunar");

		mPagerAdapter = new calendarPagerAdapter(getSupportFragmentManager());
		Log.v(TAG, "mPagerAdapter");
		
		schedulemanage2_back = (TextView) findViewById(R.id.schedulemanage2_back);
		Log.v(TAG, "schedulemanage2_back");
		schedulemanage2_back.setOnClickListener(click_schedulemanage2_back);
		Log.v(TAG, "schedulemanage2_back");
		
		schedulemanage2_viewMy = (TextView) findViewById(R.id.schedulemanage2_viewMy);
		Log.v(TAG, "schedulemanage2_viewMy");
		schedulemanage2_viewMy.setOnClickListener(click_schedulemanage2_viewMy);
		Log.v(TAG, "schedulemanage2_viewMy");
		
		schedulemanage2_list = (ListView) findViewById(R.id.schedulemanage2_list);
		
		bundle_date.putString("UserId", UserId);
		Log.v(TAG, "bundle_date");
		bundle_uid.putString("UserId", UserId);
		Log.v(TAG, "bundle_uid");
	}
	
	OnClickListener click_schedulemanage2_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_schedulemanage2_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(scheduleManage2.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };

	public void onMenuImageClick(View v) {
		switch (v.getId()) {
		case R.id.schedulemanage2_imgPreviousMonth:
			break;
		case R.id.schedulemanage2_imgNextMonth:
			break;
		case R.id.schedulemanage2_imgToday:
			break;
		case R.id.schedulemanage2_imgPopupMenu:
			PopupMenu popup = new PopupMenu(this, v);
			popup.setOnMenuItemClickListener(this);
			popup.inflate(R.menu.main_month);
			popup.show();
		}
	}
	
	@Override
	public boolean onMenuItemClick(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menuGoto:
			return true;
		case R.id.menuMonth:
			Intent it = new Intent(scheduleManage2.this , scheduleManage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
			return true;
		default:
			return false;
		}
	}

	private List<Map<String,Object>> showData()
    {
		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
		Map<String,Object> map = new HashMap<String,Object>();
    	map.put("textViewForText","");
    	list.add(map);
		return list;
    }
	
	@Override
	public void onFocusChange(View arg0, boolean arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}
}