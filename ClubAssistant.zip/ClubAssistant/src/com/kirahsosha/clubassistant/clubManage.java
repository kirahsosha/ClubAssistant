package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class clubManage extends Activity {
	
	private static final String TAG = "jby";
	
	final static int REQUEST=10;
	
	private RelativeLayout clubmanage_deleteActivity;
	private RelativeLayout clubmanage_newActivity;
	private RelativeLayout clubmanage_memberManage;
	private RelativeLayout clubmanage_exitClub;
	private TextView clubmanage_back;
	private TextView clubmanage_setup;
	
	String CID;
	String clubName;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String UserId = "";
	String result = "";
	String stClub = "";
	
	public Bundle bundle_cid = new Bundle();
	public Bundle bundle_exit = new Bundle();
	public Bundle bundle_mem = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clubmanage);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        UserId = bundle.getString("UserId");
        stClub  = bundle.getString("stClub");
        
        findAllView();
	}
	
	private void findAllView() {
		clubmanage_deleteActivity = (RelativeLayout) findViewById(R.id.clubmanage_deleteActivity);
		clubmanage_deleteActivity.setOnClickListener(click_clubmanage_deleteActivity);
		
		clubmanage_newActivity = (RelativeLayout) findViewById(R.id.clubmanage_newActivity);
		clubmanage_newActivity.setOnClickListener(click_clubmanage_newActivity);
		
		clubmanage_memberManage = (RelativeLayout) findViewById(R.id.clubmanage_memberManage);
		clubmanage_memberManage.setOnClickListener(click_clubmanage_memberManage);
		
		clubmanage_exitClub = (RelativeLayout) findViewById(R.id.clubmanage_exitClub);
		clubmanage_exitClub.setOnClickListener(click_clubmanage_exitClub);
		
		clubmanage_back = (TextView) findViewById(R.id.clubmanage_back);
		clubmanage_back.setOnClickListener(click_clubmanage_back);
		
		clubmanage_setup = (TextView) findViewById(R.id.clubmanage_setup);
		//clubmanage_setup.setOnClickListener(click_clubmanage_setup);
		
		bundle_cid.putString("UserId", UserId);
		bundle_cid.putString("CID", CID);
		bundle_cid.putString("clubName", clubName);
		bundle_cid.putString("clubType", clubType);
		bundle_cid.putString("clubSubjection", clubSubjection);
		bundle_cid.putString("clubNum", clubNum);
		bundle_cid.putString("QQ", QQ);
		bundle_cid.putString("WeiXin", WeiXin);
		bundle_cid.putString("stClub", stClub);
		
		bundle_exit.putString("UserId", UserId);
		bundle_exit.putString("CID", CID);
		bundle_exit.putString("stClub", stClub);
		
		bundle_mem.putString("UserId", UserId);
		bundle_mem.putString("CID", CID);
	}
	
	OnClickListener click_clubmanage_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    //ɾ���
    OnClickListener click_clubmanage_deleteActivity = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubManage.this , deleteActivity.class);
    		it.putExtras(bundle_cid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    //�½��
    OnClickListener click_clubmanage_newActivity = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubManage.this , newActivityInf.class);
    		it.putExtras(bundle_cid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    //��Ա����
    OnClickListener click_clubmanage_memberManage = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubManage.this , memberManage.class);
    		it.putExtras(bundle_mem);
    		startActivityForResult(it,REQUEST);
    	}
    };
    //�˳�����
    OnClickListener click_clubmanage_exitClub = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubManage.this , exitClub.class);
    		it.putExtras(bundle_exit);
    		startActivityForResult(it,REQUEST);
    	}
    };
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
}