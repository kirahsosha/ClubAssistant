package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;

public class changePassword extends Activity {
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "register.php";
	
	final static int REQUEST=10;
	
	private EditText changepassword_oldPassword;
	private EditText changepassword_newPassword;
	private EditText changepassword_newPassword_Re;
	private Button changepassword_buttonEnter;
	private Button changepassword_buttonCancel;
	
	private String textOldPassword;
	private String textNewPassword;
	private String textNewPassword_Re;
	
	private String result;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changepassword);
        
        findAllView();
		
		//getData();
    }
	
	private void findAllView()
    {
		changepassword_oldPassword = (EditText) findViewById(R.id.changepassword_oldPassword);
		changepassword_newPassword = (EditText) findViewById(R.id.changepassword_newPassword);
		changepassword_newPassword_Re = (EditText) findViewById(R.id.changepassword_newPassword_Re);
        
		changepassword_buttonEnter = (Button)findViewById(R.id.changepassword_buttonEnter);
		changepassword_buttonEnter.setOnClickListener(click_changepassword_buttonEnter);
        
		changepassword_buttonCancel = (Button)findViewById(R.id.changepassword_buttonCancel);
		changepassword_buttonCancel.setOnClickListener(click_changepassword_buttonCancel);
    }
	
	OnClickListener click_changepassword_buttonEnter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		textOldPassword = changepassword_oldPassword.getText().toString();
    		textNewPassword = changepassword_newPassword.getText().toString();
    		textNewPassword_Re = changepassword_newPassword_Re.getText().toString();
    		if(textNewPassword.equals(textNewPassword_Re))
    		{
    			//�޸�����
    			Intent in = getIntent();
        		setResult(RESULT_OK,in);
        		finish();
    		}
    		else
    		{
    			Toast.makeText(changePassword.this, "ȷ�����������������������",Toast.LENGTH_LONG ).show();
    		}
    	}
    };
    
	OnClickListener click_changepassword_buttonCancel = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
}