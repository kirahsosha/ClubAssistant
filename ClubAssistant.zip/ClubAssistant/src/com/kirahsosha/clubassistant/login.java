package com.kirahsosha.clubassistant;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EncodingUtils;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.kirahsosha.Connection.*;

public class login extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "login.php";
	private static final String FileName = "AutoLogin.txt";
	
	final static int REQUEST=10;
	
	private EditText login_editUserName;
	private EditText login_editPassword;
	private Button login_buttonRegister;
	private Button login_buttonLogin;
	private Button login_buttonBack;
	
	private String textUserId;
	private String textPassword;
	
	private String result;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        
        findAllView();
		
        AutoLogin();
		//getData();
    }

	//��������
    private void findAllView()
    {
        login_editUserName = (EditText) findViewById(R.id.login_editUserName);
        login_editPassword = (EditText) findViewById(R.id.login_editPassword);
        
        login_buttonRegister = (Button)findViewById(R.id.login_buttonRegister);
        login_buttonRegister.setOnClickListener(click_login_buttonRegister);
        
        login_buttonLogin = (Button)findViewById(R.id.login_buttonLogin);
        login_buttonLogin.setOnClickListener(click_login_buttonLogin);
        
        login_buttonBack = (Button)findViewById(R.id.login_buttonBack);
        login_buttonBack.setOnClickListener(click_login_buttonBack);
    }
    
    OnClickListener click_login_buttonLogin = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		textUserId = login_editUserName.getText().toString();
    		textPassword = login_editPassword.getText().toString();
    		Log.v(TAG,textUserId);
    		Log.v(TAG,textPassword);
    		toLogin();
    		if(result.compareTo("1") == 0)
            {
    			//�����µĵ�¼��Ϣ
        		try {
					writeFile(FileName , saveLoginFile());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	Log.v(TAG,"Login Success");
            	Toast.makeText(login.this, "��½�ɹ�",Toast.LENGTH_LONG ).show();
            	Bundle bundle = new Bundle();
            	bundle.putString("UserId", textUserId);
            	Intent it = new Intent(login.this , mypage.class);
            	it.putExtras(bundle);
    	    	if (it != null){
    				startActivityForResult(it,REQUEST);
    			}
            }
            else
            {
            	Toast.makeText(login.this, "�˺Ż��������",Toast.LENGTH_LONG ).show();
            	Log.v(TAG,"Error" + result);
            }
    	}
    };
    
    OnClickListener click_login_buttonRegister = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(login.this , register.class);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    OnClickListener click_login_buttonBack = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    public void toLogin()
    {
		Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("userid", textUserId));
		            params.add(new BasicNameValuePair("pwd", textPassword));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
						Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private void AutoLogin()
    {
    	String loginFile = "";
    	try
    	{
    		loginFile = readFile(FileName);
		}
    	catch (IOException e)
    	{
    		// TODO Auto-generated catch block
    		e.printStackTrace();
		}
    	if(loginFile != "")	//�ļ����ڣ���������
    	{
    		long TimeKey = 0;
    		try {
				JSONObject jsonObject = new JSONObject(loginFile);
				textUserId = jsonObject.optString("UserId");
				textPassword = jsonObject.optString("Password");
				TimeKey = Long.parseLong(jsonObject.optString("TimeKey"));
				Log.v(TAG , "TimeKey: " + TimeKey);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		//���ʱ��key
    		long currentTime = new Date().getTime();	//��ǰʱ���
    		Log.v(TAG , "currentTime: " + currentTime);
    		if(TimeKey <= currentTime)
    		{
    			//��֤��½��Ϣ
        		toLogin();
        		if(result.compareTo("1") == 0)
                {
        			//�����µĵ�¼��Ϣ
            		try {
    					writeFile(FileName , saveLoginFile());
    				} catch (IOException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
                	Log.v(TAG,"Login Success");
                	Toast.makeText(login.this, "��½�ɹ�",Toast.LENGTH_LONG ).show();
                	Bundle bundle = new Bundle();
                	bundle.putString("UserId", textUserId);
                	Intent it = new Intent(login.this , mypage.class);
                	it.putExtras(bundle);
        	    	if (it != null){
        				startActivityForResult(it,REQUEST);
        			}
                }
    		}
    	}
    }
    
    private String saveLoginFile()
    {
    	String saveFile = "";
    	saveFile += "{\"UserId\":\"";
    	saveFile += textUserId;
    	saveFile += "\",\"Password\":\"";
    	saveFile += textPassword;
    	saveFile += "\",\"TimeKey\":\"";
    	long currentTime = new Date().getTime();
    	saveFile += currentTime;
    	saveFile += "\"}";
    	return saveFile;
    }
    
    //д����
    public void writeFile(String fileName,String writestr) throws IOException
	{
    	try
    	{
    		FileOutputStream outputStream =this.openFileOutput(fileName, Activity.MODE_PRIVATE);
    		byte[] bytes = writestr.getBytes();
    		outputStream.write(bytes);
    		outputStream.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
	}
  	
  	//������
  	public String readFile(String fileName) throws IOException
  	{
  		String res="";
  		try
  		{
  			FileInputStream inputStream = openFileInput(fileName);
  			int length = inputStream.available();
  			if(length == 0)
  			{
  				return "";
  			}
  			byte [] buffer = new byte[length];
  			inputStream.read(buffer);   
  			res = EncodingUtils.getString(buffer, "UTF-8");
  			inputStream.close();  
  		}
  		catch(Exception e)
  		{
  			e.printStackTrace();
  		}
  		return res;
  	}
}