package com.kirahsosha.clubassistant;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.R.integer;
import android.os.Bundle;
import android.app.Activity;
import android.text.format.Time;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.content.Intent;

public class userManage extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "mypage.php";
	private static final String FileName = "AutoLogin.txt";
	
	final static int REQUEST=10;
	
	private TextView usermanage_back;
	private RelativeLayout usermanage_changePassword;
	private RelativeLayout usermanage_changeInf;
	private RelativeLayout usermanage_logout;
	private TextView usermanage_userId;
	private TextView usermanage_userName;
	private TextView usermanage_userSex;
	private TextView usermanage_userAge;
	
	String UserId;
	String result = "";
	
	public Bundle bundle_uid = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.usermanage);
        Bundle bundle = this.getIntent().getExtras();
        UserId  = bundle.getString("UserId");
        
        findAllView();
        
        getData();
        saveData();
    }
	
	//��������
    private void findAllView(){
    	usermanage_back = (TextView) findViewById(R.id.usermanage_back);
    	usermanage_back.setOnClickListener(click_usermanage_back);
    	
    	usermanage_changePassword = (RelativeLayout) findViewById(R.id.usermanage_changePassword);
    	usermanage_changePassword.setOnClickListener(click_usermanage_changePassword);
    	
    	usermanage_changeInf = (RelativeLayout) findViewById(R.id.usermanage_changeInf);
    	usermanage_changeInf.setOnClickListener(click_usermanage_changeInf);
    	
    	usermanage_logout = (RelativeLayout) findViewById(R.id.usermanage_logout);
    	usermanage_logout.setOnClickListener(click_usermanage_logout);
    	
    	usermanage_userId = (TextView) findViewById(R.id.usermanage_userId);
    	usermanage_userName = (TextView) findViewById(R.id.usermanage_userName);
    	usermanage_userSex = (TextView) findViewById(R.id.usermanage_userSex);
    	usermanage_userAge = (TextView) findViewById(R.id.usermanage_userAge);
    	
    	bundle_uid.putString("UserId", UserId);
    }
    
    OnClickListener click_usermanage_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    //�����
    OnClickListener click_usermanage_changePassword = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(userManage.this , changePassword.class);
    		it.putExtras(bundle_uid);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    //���Ź���
    OnClickListener click_usermanage_changeInf = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(userManage.this , changeUserInf.class);
    		it.putExtras(bundle_uid);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    OnClickListener click_usermanage_logout = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		try {
				writeFile(FileName , "");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		Intent it = new Intent(userManage.this , login.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    public void getData()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("userid", UserId));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                //Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	//��json�л�ȡ����
	public void saveData()
	{
		//user
		try
		{
			JSONObject jsonObject = new JSONObject(result); 
			JSONArray jsonArray = jsonObject.getJSONArray("user");
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				String UserId = jsonObject2.optString("UserId");
				String UserName = jsonObject2.optString("UserName");
				String UserSex = jsonObject2.optString("UserSex");
				String UserAge = jsonObject2.optString("UserAge");
				
				usermanage_userId.setText(UserId);
				usermanage_userName.setText(UserName);
				if(UserSex.compareTo("0") == 0)
				{
					UserSex = "male";
				}
				else
				{
					UserSex = "female";
				}
				usermanage_userSex.setText(UserSex);
				usermanage_userAge.setText(UserAge);
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
	}
	
	public void writeFile(String fileName,String writestr) throws IOException
	{
    	try
    	{
    		FileOutputStream outputStream =this.openFileOutput(fileName, Activity.MODE_PRIVATE);
    		byte[] bytes = writestr.getBytes();
    		outputStream.write(bytes);
    		outputStream.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
	}
}