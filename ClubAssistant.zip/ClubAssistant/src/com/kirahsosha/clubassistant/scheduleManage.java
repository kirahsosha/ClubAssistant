package com.kirahsosha.clubassistant;

import java.util.Calendar;

import com.kirahsosha.Calendar.calendarPagerAdapter;
import com.kirahsosha.Calendar.dateFormatter;
import com.kirahsosha.Calendar.lunarCalendar;

import android.os.Bundle;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.DatePicker;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.content.Intent;

public class scheduleManage extends FragmentActivity implements
OnDateSetListener, OnMenuItemClickListener, OnFocusChangeListener {
	
	private static final String TAG = "jby";
	
	final static int REQUEST=10;
	
	private TextView schedulemanage_back;
	private TextView schedulemanage_viewMy;
	
	private ViewPager schedulemanage_calendar;
	private PagerAdapter mPagerAdapter;
	private View schedulemanage_imgPreviousMonth, schedulemanage_imgNextMonth;
	private dateFormatter formatter;

	private TextView schedulemanage_textTitleMonth, schedulemanage_txtTitleAddition, schedulemanage_txtTitleLunar;
	
	private int getTodayMonthIndex() {
		Calendar today = Calendar.getInstance();
		int offset = (today.get(Calendar.YEAR) - lunarCalendar.getMinYear())
				* 12 + today.get(Calendar.MONTH);
		return offset;
	}
	
	public Bundle bundle_date = new Bundle();
	public Bundle bundle_uid = new Bundle();
	String UserId = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedulemanage);
        Log.v(TAG, "setContentView(R.layout.schedulemanage);");
        
        Bundle bundle = this.getIntent().getExtras();
        Log.v(TAG, "Bundle bundle = this.getIntent().getExtras();");
        UserId = bundle.getString("UserId");
        Log.v(TAG, "UserId = bundle.getString('UserId');");
        
        findAllView();
        Log.v(TAG, "findAllView();");
    }
	
	private void findAllView(){
		formatter = new dateFormatter(this.getResources());
		Log.v(TAG, "formatter = new dateFormatter(this.getResources());");

        schedulemanage_imgPreviousMonth = findViewById(R.id.schedulemanage_imgPreviousMonth);
        Log.v(TAG, "schedulemanage_imgPreviousMonth");
        schedulemanage_imgNextMonth = findViewById(R.id.schedulemanage_imgNextMonth);
        Log.v(TAG, "schedulemanage_imgNextMonth");
        schedulemanage_textTitleMonth = (TextView) findViewById(R.id.schedulemanage_textTitleMonth);
        Log.v(TAG, "schedulemanage_textTitleMonth");
        schedulemanage_txtTitleAddition = (TextView) findViewById(R.id.schedulemanage_txtTitleAddition);
        Log.v(TAG, "schedulemanage_txtTitleAddition");
        schedulemanage_txtTitleLunar = (TextView) findViewById(R.id.schedulemanage_txtTitleLunar);
        Log.v(TAG, "schedulemanage_txtTitleLunar");
        schedulemanage_calendar = (ViewPager) findViewById(R.id.schedulemanage_calendar);
        Log.v(TAG, "schedulemanage_calendar");

		mPagerAdapter = new calendarPagerAdapter(getSupportFragmentManager());
		Log.v(TAG, "mPagerAdapter");
		schedulemanage_calendar.setAdapter(mPagerAdapter);
		Log.v(TAG, "schedulemanage_calendar");
		schedulemanage_calendar.setOnPageChangeListener(new simplePageChangeListener());
		Log.v(TAG, "schedulemanage_calendar");

		schedulemanage_calendar.setCurrentItem(getTodayMonthIndex());
		Log.v(TAG, "schedulemanage_calendar");
		
		schedulemanage_back = (TextView) findViewById(R.id.schedulemanage_back);
		Log.v(TAG, "schedulemanage_back");
		schedulemanage_back.setOnClickListener(click_schedulemanage_back);
		Log.v(TAG, "schedulemanage_back");
		
		schedulemanage_viewMy = (TextView) findViewById(R.id.schedulemanage_viewMy);
		Log.v(TAG, "schedulemanage_viewMy");
		schedulemanage_viewMy.setOnClickListener(click_schedulemanage_viewMy);
		Log.v(TAG, "schedulemanage_viewMy");
		
		bundle_date.putString("UserId", UserId);
		Log.v(TAG, "bundle_date");
		bundle_uid.putString("UserId", UserId);
		Log.v(TAG, "bundle_uid");
	}
	
	OnClickListener click_schedulemanage_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_schedulemanage_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(scheduleManage.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_month, menu);
        return true;
    }

    public void onCellClick(View v) {
    	lunarCalendar lc = (lunarCalendar) v.getTag();
		int cyear = lc.getGregorianDate(Calendar.YEAR);
		int cmonth = lc.getGregorianDate(Calendar.MONTH) + 1;
		int cday = lc.getGregorianDate(Calendar.DAY_OF_MONTH);
		Log.v(TAG, Integer.toString(cyear) + "-"  + Integer.toString(cmonth) + "-" + Integer.toString(cday));
		bundle_date.putInt("year", cyear);
		bundle_date.putInt("month", cmonth);
		bundle_date.putInt("day", cday);
    	Intent it = new Intent(scheduleManage.this , dateInf.class);
    	it.putExtras(bundle_date);
		startActivityForResult(it,REQUEST);
	}
    
    @Override
    public void onDateSet(DatePicker view, int year, int monthOfYear,
			int dayOfMonth) {
		int offset = (year - lunarCalendar.getMinYear()) * 12 + monthOfYear;
		schedulemanage_calendar.setCurrentItem(offset);
	}
    
	@Override
	public void onFocusChange(View v, boolean hasFocus) {
		if (!hasFocus)
			return;
		lunarCalendar lc = (lunarCalendar) v.getTag();
		//CharSequence[] info = formatter.getFullDateInfo(lc);
		//schedulemanage_txtTitleLunar.setText(info[1]);
		//schedulemanage_txtTitleAddition.setText(info[0]);
		Log.i("cell focus", v.getTag().toString());
	}

	public void onMenuImageClick(View v) {
		switch (v.getId()) {
		case R.id.schedulemanage_imgPreviousMonth:
			schedulemanage_calendar.setCurrentItem(schedulemanage_calendar.getCurrentItem() - 1);
			break;
		case R.id.schedulemanage_imgNextMonth:
			schedulemanage_calendar.setCurrentItem(schedulemanage_calendar.getCurrentItem() + 1);
			break;
		case R.id.schedulemanage_imgToday:
			schedulemanage_calendar.setCurrentItem(getTodayMonthIndex());
			break;
		case R.id.schedulemanage_imgPopupMenu:
			PopupMenu popup = new PopupMenu(this, v);
			popup.setOnMenuItemClickListener(this);
			popup.inflate(R.menu.main_month);
			popup.show();
		}
	}
	
	@Override
	public boolean onMenuItemClick(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menuGoto:
			int year = (schedulemanage_calendar.getCurrentItem() / 12)
					+ lunarCalendar.getMinYear();
			int month = schedulemanage_calendar.getCurrentItem() % 12;
			DatePickerDialog dpd = new DatePickerDialog(
					this,
					android.R.style.Theme_DeviceDefault_DialogWhenLarge_NoActionBar,
					this, year, month, 1);
			dpd.getDatePicker().setCalendarViewShown(false);
			dpd.show();
			return true;
		case R.id.menuWeek:
			Intent it = new Intent(scheduleManage.this , scheduleManage2.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
			return true;
		default:
			return false;
		}
	}

	private class simplePageChangeListener extends
			ViewPager.SimpleOnPageChangeListener {
		@Override
		public void onPageSelected(int position) {
			// set title year month
			StringBuilder title = new StringBuilder();
			title.append(lunarCalendar.getMinYear() + (position / 12));
			title.append('-');
			int month = (position % 12) + 1;
			if (month < 10) {
				title.append('0');
			}
			title.append(month);
			schedulemanage_textTitleMonth.setText(title);
			//schedulemanage_txtTitleLunar.setText("");
			//schedulemanage_txtTitleAddition.setText("");

			// set related button's state
			if (position < mPagerAdapter.getCount() - 1
					&& !schedulemanage_imgNextMonth.isEnabled()) {
				schedulemanage_imgNextMonth.setEnabled(true);
			}
			if (position > 0 && !schedulemanage_imgPreviousMonth.isEnabled()) {
				schedulemanage_imgPreviousMonth.setEnabled(true);
			}
		}
	}
}