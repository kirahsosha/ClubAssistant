package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;

public class changeUserInf extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "register.php";
	
	final static int REQUEST=10;
	
	private EditText changeuserinf_UserName;
	private RadioGroup changeuserinf_groupSex;
	private EditText changeuserinf_Age;
	private Button changeuserinf_buttonEnter;
	private Button changeuserinf_buttonCancel;
	
	private String textUserName;
	private String textSex;
	private String textAge;
	
	private String result;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changeuserinf);
        
        findAllView();
		
		//getData();
    }
	
	private void findAllView()
    {
		changeuserinf_UserName = (EditText) findViewById(R.id.changeuserinf_UserName);
		changeuserinf_groupSex = (RadioGroup) findViewById(R.id.changeuserinf_groupSex);
		changeuserinf_groupSex.setOnCheckedChangeListener(click_changeuserinf_groupSex);
		changeuserinf_Age = (EditText) findViewById(R.id.changeuserinf_Age);
        
		changeuserinf_buttonEnter = (Button)findViewById(R.id.changeuserinf_buttonEnter);
		changeuserinf_buttonEnter.setOnClickListener(click_changeuserinf_buttonEnter);
        
		changeuserinf_buttonCancel = (Button)findViewById(R.id.changeuserinf_buttonCancel);
		changeuserinf_buttonCancel.setOnClickListener(click_changeuserinf_buttonCancel);
    }
	
	OnCheckedChangeListener click_changeuserinf_groupSex = new OnCheckedChangeListener(){
		@Override
		public void onCheckedChanged(RadioGroup arg0, int arg1) {
		//��ȡ������ѡ�����ID
		int radioButtonId = arg0.getCheckedRadioButtonId();
		//����ID��ȡRadioButton��ʵ��
		RadioButton sex = (RadioButton) findViewById(radioButtonId);
		Log.v(TAG, sex.getHint().toString());
		textSex = sex.getHint().toString();
		}
	};
	
	OnClickListener click_changeuserinf_buttonEnter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		textUserName = changeuserinf_UserName.getText().toString();
    		textAge = changeuserinf_Age.getText().toString();
    		Log.v(TAG, textUserName);
    		Log.v(TAG, textSex);
    		Log.v(TAG, textAge);
    		//�޸���Ϣ
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
	OnClickListener click_changeuserinf_buttonCancel = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
}