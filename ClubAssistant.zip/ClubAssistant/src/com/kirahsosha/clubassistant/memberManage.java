package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class memberManage extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getclubmember.php";
	
	final static int REQUEST=10;
	
	private TextView membermanage_back;
	private ListView membermanage_memberList;
	
	String UserId = "";
	String CID;
	String UID[] = new String[100];
	String UserName[] = new String[100];
	String UserSex[] = new String[100];
	String UserAge[] = new String[100];
	String UserType[] = new String[100];
	String result = "";
	
	public Bundle bundle_inf = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.membermanage);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        UserId = bundle.getString("UserId");
        
        findAllView();
        getActivityData();
        
        SimpleAdapter adapter = new SimpleAdapter(this,showData(),R.layout.membermanage_list,
                new String[]{"memberinf_list_name",
        					 "memberinf_list_type"},
                new int[]{R.id.memberinf_list_name,
        				  R.id.memberinf_list_type});
        membermanage_memberList.setAdapter(adapter);
    }
	
	private void findAllView(){
		membermanage_back = (TextView) findViewById(R.id.membermanage_back);
		membermanage_back.setOnClickListener(click_membermanage_back);
		
		membermanage_memberList = (ListView) findViewById(R.id.membermanage_memberList);
		membermanage_memberList.setOnItemClickListener(click_membermanage_memberList);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("CID", CID);
	}
	
	OnClickListener click_membermanage_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnItemClickListener click_membermanage_memberList = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		
    		bundle_inf.putString("UID", UID[position]);
    		bundle_inf.putString("UserName", UserName[position]);
    		bundle_inf.putString("UserSex", UserSex[position]);
    		bundle_inf.putString("UserAge", UserAge[position]);
			
    		Intent it = new Intent(memberManage.this, memberInf.class);
    		it.putExtras(bundle_inf);
    		if (it != null){
				startActivityForResult(it,REQUEST);
			}
		}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    public void getActivityData()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("CID", CID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private List<Map<String,Object>> showData()
    {
    	String typeString = "";
    	try
    	{
    		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    		JSONArray jsonArray = new JSONArray(result);
    		for(int i = 0 ; i < jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject = jsonArray.optJSONObject(i);
    			UID[i] = jsonObject.optString("UID");
    			UserName[i] = jsonObject.optString("UserName");
    			UserSex[i] = jsonObject.optString("UserSex");
    			UserAge[i] = jsonObject.optString("UserAge");
    			UserType[i] = jsonObject.optString("UserType");
    			
    			if(UserType[i].compareTo("1") == 0)
    			{
    				typeString = "���Ż᳤";
    			}
    			else if(UserType[i].compareTo("2") == 0)
    			{
    				typeString = "��ͨ��Ա";
    			}
    			else if(UserType[i].compareTo("3") == 0)
    			{
    				typeString = "�����г�Ա";
    			}
    	    	Map<String,Object> map = new HashMap<String,Object>();
    	    	map.put("memberinf_list_name",UserName[i]);
    	    	map.put("memberinf_list_type",typeString);
    	    	list.add(map);
    		}
    		return list;
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
			return null;
		}
    }
}