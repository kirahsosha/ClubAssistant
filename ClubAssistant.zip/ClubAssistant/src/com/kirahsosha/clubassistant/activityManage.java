package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.os.Parcelable;
import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class activityManage extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getclubinf.php";
	
	final static int REQUEST=10;
	
	private ViewPager activitymanage_mainPages;
    private ArrayList<View> pageViews;
    private ViewGroup buttonsLine;
    private Button activitymanage_all;
    private Button activitymanage_tomo;
    private Button activitymanage_undo;
    private Button activitymanage_done;
    private Button[] buttons;
	
    private ListView activityall_activitymanage;
    private ListView activitytomo_activitymanage;
    private ListView activityundo_activitymanage;
    private ListView activitydone_activitymanage;
    
    private TextView activityall_done;
    private TextView activitytomo_done;
    private TextView activityundo_done;
    private TextView activitydone_done;
    
    SimpleAdapter adapter_all;
    SimpleAdapter adapter_tomo;
    SimpleAdapter adapter_undo;
    SimpleAdapter adapter_done;
    
	public String stTomo = "";
	public String stUndo = "";
	public String stDone = "";
	public String stAll = "";
	String result = "";
	String UserId = "";
	
	public Bundle bundle_inf = new Bundle();
	public Bundle bundle_uid = new Bundle();
	
	String AID;
	String CID;
	String ActivityName;
	String ActivityTime;
	String ActivityNum;
	String ActivityPlace;
	String ClubName;
	String ClubType;
	String ClubSubjection;
	String ClubNum;
	String ClubQQ;
	String ClubWeiXin;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitymanage);
        
        Bundle bundle = this.getIntent().getExtras();
        stTomo  = bundle.getString("stTomo");
        stUndo  = bundle.getString("stUndo");
        stDone  = bundle.getString("stDone");
        stAll  = bundle.getString("stAll");
        UserId = bundle.getString("UserId");
        
        findAllView();
        
        initList();
    }
	
	private void findAllView(){
		LayoutInflater inflater = getLayoutInflater();
        pageViews = new ArrayList<View>();
        
        //�����ĸ�ҳ��
        View page01=inflater.inflate(R.layout.activityall, null);
        View page02=inflater.inflate(R.layout.activitytomorrow, null);
        View page03=inflater.inflate(R.layout.activitywait, null);
        View page04=inflater.inflate(R.layout.activitydone, null);
       
        pageViews.add(page01);
        pageViews.add(page02);
        pageViews.add(page03);
        pageViews.add(page04);
        

        //��ʼ���ĸ���ť��id�͵���¼�
        buttons = new Button[4];
        buttonsLine = (ViewGroup)inflater.inflate(R.layout.activitymanage, null);
        activitymanage_all = (Button) buttonsLine.findViewById(R.id.activitymanage_all);
        activitymanage_tomo = (Button) buttonsLine.findViewById(R.id.activitymanage_tomo);
        activitymanage_undo = (Button) buttonsLine.findViewById(R.id.activitymanage_undo);
        activitymanage_done = (Button) buttonsLine.findViewById(R.id.activitymanage_done);

        buttons[0] = activitymanage_all;
        buttons[1] = activitymanage_tomo;
        buttons[2] = activitymanage_undo;
        buttons[3] = activitymanage_done;

        
        activitymanage_all.setOnClickListener(new GuideButtonClickListener(0));
        activitymanage_tomo.setOnClickListener(new GuideButtonClickListener(1));
        activitymanage_undo.setOnClickListener(new GuideButtonClickListener(2));
        activitymanage_done.setOnClickListener(new GuideButtonClickListener(3));

        //��ʼ��ViewPager��id���¼�
        activitymanage_mainPages = (ViewPager)buttonsLine.findViewById(R.id.activitymanage_mainPages); 
        setContentView(buttonsLine);
 
        activitymanage_mainPages.setAdapter(new GuidePageAdapter());
        activitymanage_mainPages.setOnPageChangeListener(new GuidePageChangeListener());
		
		bundle_inf.putString("UserId", UserId);
		bundle_uid.putString("UserId", UserId);
	}
	
	class GuideButtonClickListener implements OnClickListener { 
		private int index = 0;
		public GuideButtonClickListener(int i) {
			index = i;
		}
		@Override
		public void onClick(View v) {
			activitymanage_mainPages.setCurrentItem(index , true);
		}
	}
	
	class GuidePageAdapter extends PagerAdapter {
		@Override 
		public int getCount() {
            return pageViews.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public int getItemPosition(Object object) {
            // TODO Auto-generated method stub
            return super.getItemPosition(object);
        }

        @Override
        public void destroyItem(View arg0, int arg1, Object arg2) {
            // TODO Auto-generated method stub
            ((ViewPager) arg0).removeView(pageViews.get(arg1));
        }

        @Override
        public Object instantiateItem(View arg0, int page) {
            // TODO Auto-generated method stub
            ((ViewPager) arg0).addView(pageViews.get(page));
            if(page == 0) showactivityall();
            if(page == 1) showactivitytomo();
            if(page == 2) showactivityundo();
            if(page == 3) showactivitydone();
            
            return pageViews.get(page); 
        } 
    	
        //��ʾȫ���
    	void showactivityall(){
    		activityall_done = (TextView)findViewById(R.id.activityall_done);
    		activityall_activitymanage = (ListView)findViewById(R.id.activityall_activityList);
    		activityall_activitymanage.setAdapter(adapter_all);
    		
    		//��û��
			try {
				JSONArray jsonArray = new JSONArray(stAll);
				int num = jsonArray.length();
	    		activityall_done.setText(Integer.toString(num));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
			//����б����¼�
			activityall_activitymanage.setOnItemClickListener(new OnItemClickListener(){
    	    	@Override
    	    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    	    		
    	    		TextView clubName= (TextView) view.findViewById(R.id.activityall_list_clubName);
    	    		TextView activityName= (TextView) view.findViewById(R.id.activityall_list_activityName);
    	    		TextView time= (TextView) view.findViewById(R.id.activityall_list_time);
    	    		TextView num= (TextView) view.findViewById(R.id.activityall_list_num);
    	    		TextView place= (TextView) view.findViewById(R.id.activityall_list_place);
    	    		bundle_inf.putString("ClubName", clubName.getText().toString());
    				bundle_inf.putString("ActivityName", activityName.getText().toString());
    				bundle_inf.putString("ActivityTime", time.getText().toString());
    				bundle_inf.putString("ActivityNum", num.getText().toString());
    				bundle_inf.putString("ActivityPlace", place.getText().toString());
    				
    	    		Intent it = new Intent(activityManage.this, activityInf.class);
    	    		it.putExtras(bundle_inf);
    	    		if (it != null){
    					startActivityForResult(it,REQUEST);
    				}
    			}
    	    });
        }
    	
        //��ʾ����
    	void showactivitytomo(){
    		activitytomo_done = (TextView)findViewById(R.id.activitytomorrow_done);
    		activitytomo_activitymanage = (ListView)findViewById(R.id.activitytomorrow_activityList);
    		activitytomo_activitymanage.setAdapter(adapter_tomo);
    		
    		//��û��
			try {
				JSONArray jsonArray = new JSONArray(stTomo);
				int num = jsonArray.length();
	    		activitytomo_done.setText(Integer.toString(num));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
			//����б����¼�
			activitytomo_activitymanage.setOnItemClickListener(new OnItemClickListener(){
    	    	@Override
    	    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    	    		
    	    		TextView clubName= (TextView) view.findViewById(R.id.activitytomorrow_list_clubName);
    	    		TextView activityName= (TextView) view.findViewById(R.id.activitytomorrow_list_activityName);
    	    		TextView time= (TextView) view.findViewById(R.id.activitytomorrow_list_time);
    	    		TextView num= (TextView) view.findViewById(R.id.activitytomorrow_list_num);
    	    		TextView place= (TextView) view.findViewById(R.id.activitytomorrow_list_place);
    	    		bundle_inf.putString("ClubName", clubName.getText().toString());
    				bundle_inf.putString("ActivityName", activityName.getText().toString());
    				bundle_inf.putString("ActivityTime", time.getText().toString());
    				bundle_inf.putString("ActivityNum", num.getText().toString());
    				bundle_inf.putString("ActivityPlace", place.getText().toString());
    				
    	    		Intent it = new Intent(activityManage.this, activityInf.class);
    	    		it.putExtras(bundle_inf);
    	    		if (it != null){
    					startActivityForResult(it,REQUEST);
    				}
    			}
    	    });
    	}
        
    	//��ʾδ��ɻ
    	void showactivityundo(){
    		activityundo_done = (TextView)findViewById(R.id.activitywait_done);
    		activityundo_activitymanage = (ListView)findViewById(R.id.activitywait_activityList);
    		activityundo_activitymanage.setAdapter(adapter_undo);
    		
    		//��û��
			try {
				JSONArray jsonArray = new JSONArray(stUndo);
				int num = jsonArray.length();
	    		activityundo_done.setText(Integer.toString(num));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
			//����б����¼�
			activityundo_activitymanage.setOnItemClickListener(new OnItemClickListener(){
    	    	@Override
    	    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    	    		
    	    		TextView clubName= (TextView) view.findViewById(R.id.activitywait_list_clubName);
    	    		TextView activityName= (TextView) view.findViewById(R.id.activitywait_list_activityName);
    	    		TextView time= (TextView) view.findViewById(R.id.activitywait_list_time);
    	    		TextView num= (TextView) view.findViewById(R.id.activitywait_list_num);
    	    		TextView place= (TextView) view.findViewById(R.id.activitywait_list_place);
    	    		bundle_inf.putString("ClubName", clubName.getText().toString());
    				bundle_inf.putString("ActivityName", activityName.getText().toString());
    				bundle_inf.putString("ActivityTime", time.getText().toString());
    				bundle_inf.putString("ActivityNum", num.getText().toString());
    				bundle_inf.putString("ActivityPlace", place.getText().toString());
    				
    	    		Intent it = new Intent(activityManage.this, activityInf.class);
    	    		it.putExtras(bundle_inf);
    	    		if (it != null){
    					startActivityForResult(it,REQUEST);
    				}
    			}
    	    });
        }
    	
    	//��ʾ����ɻ
    	void showactivitydone() {
    		activitydone_done = (TextView)findViewById(R.id.activitydone_done);
    		activitydone_activitymanage = (ListView)findViewById(R.id.activitydone_activityList);
    		activitydone_activitymanage.setAdapter(adapter_done);
    		
    		//��û��
			try {
				JSONArray jsonArray = new JSONArray(stDone);
				int num = jsonArray.length();
	    		activitydone_done.setText(Integer.toString(num));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
			//����б����¼�
			activitydone_activitymanage.setOnItemClickListener(new OnItemClickListener(){
    	    	@Override
    	    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    	    		
    	    		TextView clubName= (TextView) view.findViewById(R.id.activitydone_list_clubName);
    	    		TextView activityName= (TextView) view.findViewById(R.id.activitydone_list_activityName);
    	    		TextView time= (TextView) view.findViewById(R.id.activitydone_list_time);
    	    		TextView num= (TextView) view.findViewById(R.id.activitydone_list_num);
    	    		TextView place= (TextView) view.findViewById(R.id.activitydone_list_place);
    	    		bundle_inf.putString("ClubName", clubName.getText().toString());
    				bundle_inf.putString("ActivityName", activityName.getText().toString());
    				bundle_inf.putString("ActivityTime", time.getText().toString());
    				bundle_inf.putString("ActivityNum", num.getText().toString());
    				bundle_inf.putString("ActivityPlace", place.getText().toString());
    				
    	    		Intent it = new Intent(activityManage.this, activityInf.class);
    	    		it.putExtras(bundle_inf);
    	    		if (it != null){
    					startActivityForResult(it,REQUEST);
    				}
    			}
    	    });
    	}
    	
        @Override 
        public void restoreState(Parcelable arg0, ClassLoader arg1) { 
            // TODO Auto-generated method stub 
 
        } 
 
        @Override 
        public Parcelable saveState() { 
            // TODO Auto-generated method stub 
            return null; 
        } 
 
        @Override 
        public void startUpdate(View arg0) { 
            // TODO Auto-generated method stub 
 
        } 
 
        @Override 
        public void finishUpdate(View arg0) { 
            // TODO Auto-generated method stub 
 
        } 
    }
    
	class GuidePageChangeListener implements OnPageChangeListener {
		
		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void onPageSelected(int arg0) {
			// TODO Auto-generated method stub
		}
	}
	
	OnClickListener click_activitytomorrow_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_activitytomorrow_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(activityManage.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnItemClickListener click_activitytomorrow_activitymanage = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		
    		TextView clubName= (TextView) view.findViewById(R.id.activitytomorrow_list_clubName);
    		TextView activityName= (TextView) view.findViewById(R.id.activitytomorrow_list_activityName);
    		TextView time= (TextView) view.findViewById(R.id.activitytomorrow_list_time);
    		TextView num= (TextView) view.findViewById(R.id.activitytomorrow_list_num);
    		TextView place= (TextView) view.findViewById(R.id.activitytomorrow_list_place);
    		bundle_inf.putString("ClubName", clubName.getText().toString());
			bundle_inf.putString("ActivityName", activityName.getText().toString());
			bundle_inf.putString("ActivityTime", time.getText().toString());
			bundle_inf.putString("ActivityNum", num.getText().toString());
			bundle_inf.putString("ActivityPlace", place.getText().toString());
			
    		Intent it = new Intent(activityManage.this, activityInf.class);
    		it.putExtras(bundle_inf);
    		if (it != null){
				startActivityForResult(it,REQUEST);
			}
		}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    //��ʼ��list��ʾ������
    public void initList() {
    	adapter_all = new SimpleAdapter(this,showData(stAll),R.layout.activityall_list,
                new String[]{"list_clubName",
							 "list_activityName",
							 "list_time",
							 "list_num",
							 "list_place"},
                new int[]{
						  R.id.activityall_list_clubName,
						  R.id.activityall_list_activityName,
						  R.id.activityall_list_time,
						  R.id.activityall_list_num,
						  R.id.activityall_list_place});
    	
    	adapter_tomo = new SimpleAdapter(this,showData(stTomo),R.layout.activitytomorrow_list,
                new String[]{"list_clubName",
							 "list_activityName",
							 "list_time",
							 "list_num",
							 "list_place"},
                new int[]{
						  R.id.activitytomorrow_list_clubName,
						  R.id.activitytomorrow_list_activityName,
						  R.id.activitytomorrow_list_time,
						  R.id.activitytomorrow_list_num,
						  R.id.activitytomorrow_list_place});
    	
    	adapter_undo = new SimpleAdapter(this,showData(stUndo),R.layout.activitywait_list,
                new String[]{"list_clubName",
							 "list_activityName",
							 "list_time",
							 "list_num",
							 "list_place"},
                new int[]{
						  R.id.activitywait_list_clubName,
						  R.id.activitywait_list_activityName,
						  R.id.activitywait_list_time,
						  R.id.activitywait_list_num,
						  R.id.activitywait_list_place});
    	
    	adapter_done = new SimpleAdapter(this,showData(stDone),R.layout.activitydone_list,
                new String[]{"list_clubName",
							 "list_activityName",
							 "list_time",
							 "list_num",
							 "list_place"},
                new int[]{
						  R.id.activitydone_list_clubName,
						  R.id.activitydone_list_activityName,
						  R.id.activitydone_list_time,
						  R.id.activitydone_list_num,
						  R.id.activitydone_list_place});
    }
    
    private List<Map<String,Object>> showData(String jString)
    {
    	try
    	{
    		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    		
    		JSONArray jsonArray = new JSONArray(jString);
    		for(int i = 0 ; i < jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject = jsonArray.optJSONObject(i);
    			AID = jsonObject.optString("AID");
				CID = jsonObject.optString("CID");
				ActivityName = jsonObject.optString("ActivityName");
				ActivityTime = jsonObject.optString("ActivityTime");
				ActivityNum = jsonObject.optString("ActivityNum");
				ActivityPlace = jsonObject.optString("ActivityPlace");
				
				getClubName();
				saveData(result);
				
				Map<String,Object> map = new HashMap<String,Object>();
		    	map.put("list_clubName" , ClubName);
		    	map.put("list_activityName" , ActivityName);
		    	map.put("list_time" , ActivityTime);
		    	map.put("list_num" , ActivityNum);
		    	map.put("list_place" , ActivityPlace);
		    	list.add(map);
    		}
    		return list;
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
			return null;
		}
    }
    
    public void getClubName()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("clubid", CID));
		            Log.v(TAG,"444");
		            Log.v(TAG,"CID = " + CID);
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                //Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void saveData(String jString)
	{
		try
		{
			JSONObject jsonObject = new JSONObject(jString); 
			JSONArray jsonArray = jsonObject.optJSONArray("club");
			String stClub = "";
			Log.v(TAG,Integer.toString(jsonArray.length()));
			stClub = jsonArray.toString();
			Log.v(TAG, "stClub = " + stClub);
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				ClubName = jsonObject2.optString("ClubName");
				ClubType = jsonObject2.optString("ClubType");
				ClubSubjection = jsonObject2.optString("ClubSubjection");
				ClubNum = jsonObject2.optString("ClubNum");
				ClubQQ = jsonObject2.optString("ClubQQ");
				ClubWeiXin = jsonObject2.optString("ClubWeiXin");
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
	}
}