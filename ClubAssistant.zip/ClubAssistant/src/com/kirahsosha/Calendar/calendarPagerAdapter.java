package com.kirahsosha.Calendar;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class calendarPagerAdapter extends FragmentStatePagerAdapter {

	public calendarPagerAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		return calendarPagerFragment.create(position);
	}

	@Override
	public int getCount() {
		int years = lunarCalendar.getMaxYear() - lunarCalendar.getMinYear();
		return years * 12;
	}

}
