package com.kirahsosha.clubassistant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class activityInf extends Activity {
	
	final static int REQUEST=10;
	
	private TextView activityinf_back;
	private TextView activityinf_viewMy;
	private TextView activityinf_clubName;
	private TextView activityinf_activityName;
	private TextView activityinf_time;
	private TextView activityinf_num;
	private TextView activityinf_place;
	
	String ClubName;
	String ActivityName;
	String ActivityTime;
	String ActivityNum;
	String ActivityPlace;
	
	public Bundle bundle_uid = new Bundle();
	String UserId = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activityinf);
        
        Bundle bundle = this.getIntent().getExtras();
        ClubName  = bundle.getString("ClubName");
        ActivityName  = bundle.getString("ActivityName");
        ActivityTime  = bundle.getString("ActivityTime");
        ActivityNum  = bundle.getString("ActivityNum");
        ActivityPlace  = bundle.getString("ActivityPlace");
        UserId = bundle.getString("UserId");
        
        findAllView();
        showData();
	}
	
	private void findAllView(){
		activityinf_back = (TextView) findViewById(R.id.activityinf_back);
		activityinf_back.setOnClickListener(click_activityinf_back);
		
		activityinf_viewMy = (TextView) findViewById(R.id.activityinf_viewMy);
		activityinf_viewMy.setOnClickListener(click_activityinf_viewMy);
		
		activityinf_clubName = (TextView) findViewById(R.id.activityinf_clubName);
		activityinf_activityName = (TextView) findViewById(R.id.activityinf_activityName);
		activityinf_time = (TextView) findViewById(R.id.activityinf_time);
		activityinf_num = (TextView) findViewById(R.id.activityinf_num);
		activityinf_place = (TextView) findViewById(R.id.activityinf_place);
		
		bundle_uid.putString("UserId", UserId);
	}
	
	OnClickListener click_activityinf_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_activityinf_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(activityInf.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    private void showData()
    {
    	activityinf_clubName.setText(ClubName);
    	activityinf_activityName.setText(ActivityName);
    	activityinf_time.setText(ActivityTime);
    	activityinf_num.setText(ActivityNum);
    	activityinf_place.setText(ActivityPlace);
    }
}