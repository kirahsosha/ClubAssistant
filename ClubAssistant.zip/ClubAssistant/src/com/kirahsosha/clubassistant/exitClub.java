package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class exitClub extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "exitclub.php";
	
	final static int REQUEST=10;
	
	private Button exitclub_enter;
	private Button exitclub_cancel;
	
	String UserId = "";
	String CID = "";
	String stClub = "";
	String result = "";
	
	public Bundle bundle_exit = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exitclub);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        UserId = bundle.getString("UserId");
        stClub  = bundle.getString("stClub");
        
        findAllView();
	}
	
	private void findAllView() {
		exitclub_enter = (Button) findViewById(R.id.exitclub_enter);
		exitclub_enter.setOnClickListener(click_exitclub_enter);
		
		exitclub_cancel = (Button) findViewById(R.id.exitclub_cancel);
		exitclub_cancel.setOnClickListener(click_exitclub_cancel);
		
		bundle_exit.putString("UserId", UserId);
	}
	
	OnClickListener click_exitclub_enter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		ifDelete();
    		if(result.compareTo("1") == 0)
    		{
    			Toast.makeText(exitClub.this, "���Ż᳤�޷��˳����ţ�",Toast.LENGTH_LONG ).show();
    		}
    		else if(result.compareTo("2") == 0)
    		{
    			Toast.makeText(exitClub.this, "�ɹ��˳����ţ�",Toast.LENGTH_LONG ).show();
    			String newst = changeST();
    			bundle_exit.putString("stClub", newst);
    			Intent it = new Intent(exitClub.this , clubList.class);
        		it.putExtras(bundle_exit);
        		startActivityForResult(it,REQUEST);
    		}
    	}
    };
    
	OnClickListener click_exitclub_cancel = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    public void ifDelete()
    {
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("CID", CID));
		            HttpPost httpRequest = new HttpPost(url);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	//
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private String changeST()
    {
    	String newString = "[";
    	int j = 0;
    	
    	try
    	{
    		JSONArray jsonArray = new JSONArray(stClub);
    		
    		for(int i = 0 ; i < jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject = jsonArray.optJSONObject(i);
    			String tCID = jsonObject.optString("CID");
    			String ClubName = jsonObject.optString("ClubName");
    			String ClubType = jsonObject.optString("ClubType");
    			String ClubSubjection = jsonObject.optString("ClubSubjection");
    			String ClubNum = jsonObject.optString("ClubNum");
    			String ClubQQ = jsonObject.optString("ClubQQ");
    			String ClubWeiXin = jsonObject.optString("ClubWeiXin");
    			
    			if(tCID.compareTo(CID) != 0)
    			{
    				if(j != 0)
    				{
    					newString += ",";
    				}
    				else
    				{
    					j++;
    				}
    				newString += "{\"CID\":\"" + tCID;
    				newString += "\",\"ClubName\":\"" + ClubName;
    				newString += "\",\"ClubType\":\"" + ClubType;
    				newString += "\",\"ClubSubjection\":\"" + ClubSubjection;
    				newString += "\",\"ClubNum\":\"" + ClubNum;
    				newString += "\",\"ClubQQ\":\"" + ClubQQ;
    				newString += "\",\"ClubWeiXin\":\"" + ClubWeiXin;
    				newString += "\"}";
    			}
    		}
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
    	newString += "]";
    	return newString;
    }
}