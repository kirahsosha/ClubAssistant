package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class clubInf extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getclubactivity.php";
	private static final String urlif = connectIP.IP + "ifmember.php";
	private static final String urladd = connectIP.IP + "addtoclub.php";
	
	final static int REQUEST=10;
	
	private TextView clubinf_back;
	private TextView clubinf_viewMy;
	private TextView clubinf_clubName;
	private TextView clubinf_clubType;
	private TextView clubinf_clubSubjection;
	private TextView clubinf_clubNum;
	private TextView clubinf_QQ;
	private TextView clubinf_WeiXin;
	private ListView clubinf_activityList;
	private TextView clubinf_clubActivityNum;
	private TextView clubinf_done;
	private TextView clubinf_clubManage;
	
	String CID;
	String clubName;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String[] AID = new String[100];
	String ActivityName;
	String ActivityTime;
	String ActivityEndTime;
	String ActivityTimeTag;
	String ActivityNum;
	String ActivityPlace;
	
	int numAll = 0;
	int numDone = 0;
	int ifmembernum = 0;
	
	public Bundle bundle_uid = new Bundle();
	public Bundle bundle_cid = new Bundle();
	public Bundle bundle_inf = new Bundle();
	public Bundle bundle_back = new Bundle();
	
	String UserId = "";
	String result = "";
	String resultadd = "";
	String stClub = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clubinf);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        UserId = bundle.getString("UserId");
        stClub  = bundle.getString("stClub");
        
        findAllView();
        
        ifMember();
        if(ifmembernum == 0)
        {
        	clubinf_clubManage.setText("��������");
        }
        showData();
        getActivityData();
        
        SimpleAdapter adapter = new SimpleAdapter(this,showActivityData(),R.layout.clubinf_list,
                new String[]{"clubinf_list_activityName",
							 "clubinf_list_time",
							 "clubinf_list_timeTag",
							 "clubinf_list_num",
							 "clubinf_list_place"},
                new int[]{R.id.clubinf_list_activityName,
						  R.id.clubinf_list_time,
						  R.id.clubinf_list_timeTag,
						  R.id.clubinf_list_num,
						  R.id.clubinf_list_place});
        clubinf_activityList.setAdapter(adapter);
	}
	
	private void findAllView(){
		clubinf_back = (TextView) findViewById(R.id.clubinf_back);
		clubinf_back.setOnClickListener(click_clubinf_back);
		
		clubinf_viewMy = (TextView) findViewById(R.id.clubinf_viewMy);
		clubinf_viewMy.setOnClickListener(click_clubinf_viewMy);
		
		clubinf_clubManage = (TextView) findViewById(R.id.clubinf_clubManage);
		clubinf_clubManage.setOnClickListener(click_clubinf_clubManage);
		
		clubinf_clubName = (TextView) findViewById(R.id.clubinf_clubName);
		clubinf_clubType = (TextView) findViewById(R.id.clubinf_clubType);
		clubinf_clubSubjection = (TextView) findViewById(R.id.clubinf_clubSubjection);
		clubinf_clubNum = (TextView) findViewById(R.id.clubinf_clubNum);
		clubinf_QQ = (TextView) findViewById(R.id.clubinf_QQ);
		clubinf_WeiXin = (TextView) findViewById(R.id.clubinf_WeiXin);
		
		clubinf_clubActivityNum = (TextView) findViewById(R.id.clubinf_clubActivityNum);
		clubinf_done = (TextView) findViewById(R.id.clubinf_done);
		
		clubinf_activityList = (ListView) findViewById(R.id.clubinf_activityList);
		clubinf_activityList.setOnItemClickListener(click_clubinf_activityList);
		
		bundle_uid.putString("UserId", UserId);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("clubName", clubName);
		bundle_inf.putString("CID", CID);
		bundle_inf.putString("clubType", clubType);
		bundle_inf.putString("clubSubjection", clubSubjection);
		bundle_inf.putString("clubNum", clubNum);
		bundle_inf.putString("QQ", QQ);
		bundle_inf.putString("WeiXin", WeiXin);
		bundle_inf.putString("stClub", stClub);
		
		bundle_cid.putString("UserId", UserId);
		bundle_cid.putString("CID", CID);
		bundle_cid.putString("clubName", clubName);
		bundle_cid.putString("clubType", clubType);
		bundle_cid.putString("clubSubjection", clubSubjection);
		bundle_cid.putString("clubNum", clubNum);
		bundle_cid.putString("QQ", QQ);
		bundle_cid.putString("WeiXin", WeiXin);
		bundle_cid.putString("stClub", stClub);
		
		bundle_back.putString("UserId", UserId);
		bundle_back.putString("stClub", stClub);
	}
	
	OnClickListener click_clubinf_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubInf.this , clubList.class);
    		it.putExtras(bundle_back);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnClickListener click_clubinf_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubInf.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnClickListener click_clubinf_clubManage = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		if(ifmembernum == 1)
    		{
    			Intent it = new Intent(clubInf.this , clubManage.class);
    			it.putExtras(bundle_cid);
    			startActivityForResult(it,REQUEST);
    		}
    		else
    		{
    			addToClub();
    			if(resultadd.compareTo("1") == 0)
    			{
    				Toast.makeText(clubInf.this, "�ѷ��ͼ�������",Toast.LENGTH_LONG ).show();
    			}
    		}
    	}
    };
    
    OnItemClickListener click_clubinf_activityList = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		if(ifmembernum == 1)
    		{
    			bundle_inf.putString("AID", AID[position]);
        		Log.v(TAG,"AID = " + AID[position]);
        		Intent it = new Intent(clubInf.this, clubActivityInf.class);
        		it.putExtras(bundle_inf);
        		if (it != null){
    				startActivityForResult(it,REQUEST);
    			}
    		}
		}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    private void showData()
    {
    	clubinf_clubName.setText(clubName);
    	clubinf_clubType.setText(clubType);
    	clubinf_clubSubjection.setText(clubSubjection);
    	clubinf_clubNum.setText(clubNum);
    	clubinf_QQ.setText(QQ);
    	clubinf_WeiXin.setText(WeiXin);
    }
    
    public void getActivityData()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("CID", CID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
    public void ifMember()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("CID", CID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(urlif);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	String resultif = EntityUtils.toString(httpResponse.getEntity());
		            	ifmembernum = Integer.parseInt(resultif);
		                Log.v(TAG,"resultif = "+resultif);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void addToClub()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("CID", CID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(urladd);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	resultadd = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"resultadd = "+resultadd);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private List<Map<String,Object>> showActivityData(){
    	List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    	Map<String,Object> map;
    	
    	try
		{
			JSONObject jsonObject = new JSONObject(result); 
			JSONArray jsonArray = jsonObject.getJSONArray("activity");
			
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				AID[i] = jsonObject2.optString("AID");
				CID = jsonObject2.optString("CID");
				ActivityName = jsonObject2.optString("ActivityName");
				ActivityTime = jsonObject2.optString("ActivityTime");
				ActivityEndTime = jsonObject2.optString("ActivityEndTime");
				ActivityTimeTag = jsonObject2.optString("ActivityTimeTag");
				ActivityNum = jsonObject2.optString("ActivityNum");
				ActivityPlace = jsonObject2.optString("ActivityPlace");
				
				numAll ++;
				numDone ++;
				String timeTagString = "";
				
				if(ActivityTimeTag.compareTo("0") == 0)
				{
					timeTagString = "��ȷ��";
				}
				else if(ActivityTimeTag.compareTo("1") == 0)
				{
					timeTagString = "δɸѡ";
				}
				else if(ActivityTimeTag.compareTo("2") == 0)
				{
					timeTagString = "δͶƱ";
				}
				else if(ActivityTimeTag.compareTo("3") == 0)
				{
					timeTagString = "δȷ��";
				}
				
				map = new HashMap<String,Object>();
		    	map.put("clubinf_list_activityName" , ActivityName);
		    	map.put("clubinf_list_time" , ActivityTime + " - " + ActivityEndTime);
		    	map.put("clubinf_list_timeTag" , timeTagString);
		    	map.put("clubinf_list_num" , ActivityNum);
		    	map.put("clubinf_list_place" , ActivityPlace);
		    	list.add(map);
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
    	
    	clubinf_clubActivityNum.setText(Integer.toString(numDone));
    	
    	return list;
    }
}