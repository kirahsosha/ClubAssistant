package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class clubActivityInf extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getactivityinf.php";
	
	final static int REQUEST=10;
	
	private TextView clubactivityinf_back;
	private TextView clubactivityinf_viewMy;
	private TextView clubactivityinf_clubName;
	private TextView clubactivityinf_activityName;
	private TextView clubactivityinf_timeTag;
	private TextView clubactivityinf_num;
	private TextView clubactivityinf_place;
	private Button clubactivityinf_buttonTimeTag;
	private ListView clubactivityinf_list;
	
	String AID;
	String CID;
	String clubName;
	String ActivityName;
	String ActivityTime;
	String ActivityEndTime;
	String ActivityTimeTag;
	String ActivityNum;
	String ActivityPlace;
	String timeTagString;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String stClub;
	
	String ATID[] = new String[100];
	String StartTime[] = new String[100];
	String EndTime[] = new String[100];
	String TimeTag[] = new String[100];
	
	public Bundle bundle_uid = new Bundle();
	public Bundle bundle_inf = new Bundle();
	public Bundle bundle_back = new Bundle();
	
	String UserId = "";
	String result = "";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clubactivityinf);
        
        Bundle bundle = this.getIntent().getExtras();
        AID  = bundle.getString("AID");
        CID  = bundle.getString("CID");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        UserId = bundle.getString("UserId");
        stClub  = bundle.getString("stClub");
        
        findAllView();
        getActivityData();
        showData();
        
        SimpleAdapter adapter = new SimpleAdapter(this,showTime(),R.layout.clubactivityinf_list,
        		new String[]{"clubactivityinf_list_timeTest",
        					 "clubactivityinf_list_check",},
        		new int[]{R.id.clubactivityinf_list_timeTest,
        				  R.id.clubactivityinf_list_check,});
        clubactivityinf_list.setAdapter(adapter);
	}
	
	private void findAllView(){
		clubactivityinf_back = (TextView) findViewById(R.id.clubactivityinf_back);
		clubactivityinf_back.setOnClickListener(click_clubactivityinf_back);
		
		clubactivityinf_viewMy = (TextView) findViewById(R.id.clubactivityinf_viewMy);
		clubactivityinf_viewMy.setOnClickListener(click_clubactivityinf_viewMy);
		
		clubactivityinf_buttonTimeTag = (Button) findViewById(R.id.clubactivityinf_buttonTimeTag);
		clubactivityinf_buttonTimeTag.setOnClickListener(click_clubactivityinf_buttonTimeTag);
		
		clubactivityinf_clubName = (TextView) findViewById(R.id.clubactivityinf_clubName);
		clubactivityinf_activityName = (TextView) findViewById(R.id.clubactivityinf_activityName);
		clubactivityinf_timeTag = (TextView) findViewById(R.id.clubactivityinf_timeTag);
		clubactivityinf_num = (TextView) findViewById(R.id.clubactivityinf_num);
		clubactivityinf_place = (TextView) findViewById(R.id.clubactivityinf_place);
		
		clubactivityinf_list = (ListView) findViewById(R.id.clubactivityinf_timeList);
		//clubactivityinf_list.setOnItemClickListener(click_clubactivityinf_list);
		
		bundle_uid.putString("UserId", UserId);
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("AID", AID);
		bundle_inf.putString("clubName", clubName);
		
		bundle_back.putString("UserId", UserId);
		bundle_back.putString("clubName", clubName);
		bundle_back.putString("CID", CID);
		bundle_back.putString("clubType", clubType);
		bundle_back.putString("clubSubjection", clubSubjection);
		bundle_back.putString("clubNum", clubNum);
		bundle_back.putString("QQ", QQ);
		bundle_back.putString("WeiXin", WeiXin);
		bundle_back.putString("stClub", stClub);
	}
	
	OnClickListener click_clubactivityinf_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubActivityInf.this , clubInf.class);
    		it.putExtras(bundle_back);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnClickListener click_clubactivityinf_viewMy = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(clubActivityInf.this , mypage.class);
    		it.putExtras(bundle_uid);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnClickListener click_clubactivityinf_buttonTimeTag = new OnClickListener(){
    	@Override
    	public void onClick(View v){	//��ת����
    		Log.v(TAG , ActivityTimeTag);
    		if(ActivityTimeTag.compareTo("1") == 0)
			{
    			Log.v(TAG , ActivityTimeTag);
    			Intent it = new Intent(clubActivityInf.this , timeSelect1.class);
        		it.putExtras(bundle_inf);
        		startActivityForResult(it,REQUEST);
			}
			else if(ActivityTimeTag.compareTo("2") == 0)
			{
				Intent it = new Intent(clubActivityInf.this , timeSelect2.class);
	    		it.putExtras(bundle_inf);
	    		startActivityForResult(it,REQUEST);
			}
			else if(ActivityTimeTag.compareTo("3") == 0)
			{
				Intent it = new Intent(clubActivityInf.this , timeSelect3.class);
	    		it.putExtras(bundle_inf);
	    		startActivityForResult(it,REQUEST);
			}
    	}
    };
    /*
    OnItemClickListener click_clubactivityinf_list = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		
    		Intent it = new Intent(clubActivityInf.this, activityInf.class);
    		bundle_inf.putString("AID", AID);
    		it.putExtras(bundle_inf);
    		if (it != null){
				startActivityForResult(it,REQUEST);
			}
		}
    };
    */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    private void showData()
    {
    	try
		{
			JSONObject jsonObject = new JSONObject(result); 
			JSONArray jsonArray = jsonObject.getJSONArray("activity");
			
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				AID = jsonObject2.optString("AID");
				CID = jsonObject2.optString("CID");
				ActivityName = jsonObject2.optString("ActivityName");
				ActivityTime = jsonObject2.optString("ActivityTime");
				ActivityEndTime = jsonObject2.optString("ActivityEndTime");
				ActivityTimeTag = jsonObject2.optString("ActivityTimeTag");
				ActivityNum = jsonObject2.optString("ActivityNum");
				ActivityPlace = jsonObject2.optString("ActivityPlace");
				
				if(ActivityTimeTag.compareTo("0") == 0)
				{
					timeTagString = "��ȷ��";
					clubactivityinf_buttonTimeTag.setVisibility(View.INVISIBLE);
				}
				else if(ActivityTimeTag.compareTo("1") == 0)
				{
					timeTagString = "δɸѡ";
					clubactivityinf_buttonTimeTag.setText("ɸѡʱ��");
				}
				else if(ActivityTimeTag.compareTo("2") == 0)
				{
					timeTagString = "δͶƱ";
					clubactivityinf_buttonTimeTag.setText("ͶƱѡ��");
				}
				else if(ActivityTimeTag.compareTo("3") == 0)
				{
					timeTagString = "δȷ��";
					clubactivityinf_buttonTimeTag.setText("ȷ��ʱ��");
				}
			}
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
    	clubactivityinf_clubName.setText(clubName);
    	clubactivityinf_activityName.setText(ActivityName);
    	clubactivityinf_timeTag.setText(timeTagString);
    	clubactivityinf_num.setText(ActivityNum);
    	clubactivityinf_place.setText(ActivityPlace);
    }
    
    public void getActivityData()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("AID", AID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private List<Map<String,Object>> showTime()
    {
    	try
    	{
    		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    		
    		JSONObject jsonObject = new JSONObject(result); 
			JSONArray jsonArray = jsonObject.getJSONArray("time");
			bundle_inf.putString("result", jsonArray.toString());
    		for(int i = 0 ; i < jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject2 = jsonArray.optJSONObject(i);
    			ATID[i] = jsonObject2.optString("ATID");
    			StartTime[i] = jsonObject2.optString("StartTime");
				EndTime[i] = jsonObject2.optString("EndTime");
				TimeTag[i] = jsonObject2.optString("TimeTag");
				
				Map<String,Object> map = new HashMap<String,Object>();
		    	map.put("clubactivityinf_list_timeTest" , StartTime[i] + " - " + EndTime[i]);
		    	map.put("clubactivityinf_list_check" , TimeTag[i]);
		    	list.add(map);
    		}
	    	
    		return list;
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
			return null;
		}
    }
}