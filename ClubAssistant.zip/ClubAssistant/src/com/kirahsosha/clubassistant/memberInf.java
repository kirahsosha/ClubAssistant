package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class memberInf extends Activity {
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "kickclubmember.php";
	
	final static int REQUEST=10;
	
	private TextView memberinf_back;
	private TextView memberinf_name;
	private TextView memberinf_age;
	private TextView memberinf_sex;
	private Button memberinf_kickButton;
	
	String UserId = "";
	String CID;
	String UID;
	String UserName;
	String UserSex;
	String UserAge;
	String result = "";
	
	public Bundle bundle_inf = new Bundle();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memberinf);
        
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        UserId = bundle.getString("UserId");
        UID = bundle.getString("UID");
        UserName = bundle.getString("UserName");
        UserSex = bundle.getString("UserSex");
        UserAge = bundle.getString("UserAge");
        
        findAllView();
    }
	
	private void findAllView(){
		memberinf_back = (TextView) findViewById(R.id.memberinf_back);
		memberinf_back.setOnClickListener(click_memberinf_back);
		
		memberinf_name = (TextView) findViewById(R.id.memberinf_name);
		memberinf_name.setText(UserName);
		
		memberinf_age = (TextView) findViewById(R.id.memberinf_age);
		memberinf_age.setText(UserAge);
		
		memberinf_sex = (TextView) findViewById(R.id.memberinf_sex);
		if(UserSex.compareTo("0") == 0)
		{
			memberinf_sex.setText("male");
		}
		else
		{
			memberinf_sex.setText("female");
		}
		
		memberinf_kickButton = (Button) findViewById(R.id.memberinf_kickButton);
		memberinf_kickButton.setOnClickListener(click_memberinf_kickButton);
		memberinf_kickButton.setText("�߳�����");
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("CID", CID);
	}
	
	OnClickListener click_memberinf_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_memberinf_kickButton = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		kickMember();
    		if(result.compareTo("1") == 0)
    		{
    			Toast.makeText(memberInf.this, "���Ż᳤�޷��߳����ţ�",Toast.LENGTH_LONG ).show();
    		}
    		else if(result.compareTo("2") == 0)
    		{
    			Toast.makeText(memberInf.this, "�ɹ��߳����ţ�",Toast.LENGTH_LONG ).show();
    			Intent it = new Intent(memberInf.this , memberManage.class);
        		it.putExtras(bundle_inf);
        		startActivityForResult(it,REQUEST);
    		}
    	}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    public void kickMember()
    {
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("UID", UID));
		            params.add(new BasicNameValuePair("CID", CID));
		            HttpPost httpRequest = new HttpPost(url);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}