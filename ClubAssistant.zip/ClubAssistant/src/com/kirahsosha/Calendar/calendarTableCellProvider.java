package com.kirahsosha.Calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;

import com.kirahsosha.clubassistant.R;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class calendarTableCellProvider {

	private long firstDayMillis = 0;
	private int solarTerm1 = 0;
	private int solarTerm2 = 0;
	private dateFormatter fomatter;
	
	public calendarTableCellProvider(Resources resources, int monthIndex){
		int year = lunarCalendar.getMinYear() + (monthIndex / 12);
		int month = monthIndex % 12;
		Calendar date = new GregorianCalendar(year, month, 1);
		int offset = 1 - date.get(Calendar.DAY_OF_WEEK);
		date.add(Calendar.DAY_OF_MONTH, offset);
		firstDayMillis = date.getTimeInMillis();
		solarTerm1 = lunarCalendar.getSolarTerm(year, month * 2 + 1);
		solarTerm2 = lunarCalendar.getSolarTerm(year, month * 2 + 2);
		fomatter = new dateFormatter(resources);
	}
	
	public View getView(int position, LayoutInflater inflater, ViewGroup container) {
		ViewGroup rootView;
		lunarCalendar date = new lunarCalendar(firstDayMillis + 
				(position - (position / 8) - 1) * lunarCalendar.DAY_MILLIS);
		// 周的年内序号
		if (position % 8 == 0){
			rootView = (ViewGroup) inflater.inflate(R.layout.view_calendar_week_index, container, false);

			TextView txtWeekIndex = (TextView)rootView.findViewById(R.id.txtWeekIndex);
			txtWeekIndex.setText(String.valueOf(date.getGregorianDate(Calendar.WEEK_OF_YEAR)));

			return rootView;
		}

		// �?始日期处�?
		boolean isFestival = false, isSolarTerm = false;
		rootView = (ViewGroup) inflater.inflate(R.layout.view_calendar_day_cell, container, false);
		TextView txtCellGregorian = (TextView)rootView.findViewById(R.id.txtCellGregorian);
		TextView txtCellLunar = (TextView)rootView.findViewById(R.id.txtCellLunar);
		
		int gregorianDay = date.getGregorianDate(Calendar.DAY_OF_MONTH);
		// 判断是否为本月日�?
		boolean isOutOfRange = ((position % 8 != 0) && 
				(position < 8 && gregorianDay > 7) || (position > 8 && gregorianDay < position - 7 - 6));
		txtCellGregorian.setText(String.valueOf(gregorianDay));

		// 农历节日 > 公历节日 > 农历月份 > 二十四节�? > 农历�?
		int index = date.getLunarFestival();
		if (index >= 0){
			// 农历节日
			txtCellLunar.setText(fomatter.getLunarFestivalName(index));
			isFestival = true;
		}else{
			//index = date.getGregorianFestival();
			if (index >= 0){
				// 公历节日
				//txtCellLunar.setText(fomatter.getGregorianFestivalName(index));
				isFestival = true;
			}else if (date.getLunar(lunarCalendar.LUNAR_DAY) == 1){
				// 初一,显示月份
				txtCellLunar.setText(fomatter.getMonthName(date));
			}else if(!isOutOfRange && gregorianDay == solarTerm1){
				// 节气1
				txtCellLunar.setText(fomatter.getSolarTermName(date.getGregorianDate(Calendar.MONTH) * 2));
				isSolarTerm = true;
			}else if(!isOutOfRange && gregorianDay == solarTerm2){
				// 节气2
				txtCellLunar.setText(fomatter.getSolarTermName(date.getGregorianDate(Calendar.MONTH) * 2 + 1));
				isSolarTerm = true;
			}else{
				txtCellLunar.setText(fomatter.getDayName(date));
			}
		}
		
		// set style
		Resources resources = container.getResources();
		if (isOutOfRange){
			rootView.setBackgroundResource(R.drawable.selector_calendar_outrange);
			txtCellGregorian.setTextColor(resources.getColor(R.color.color_calendar_outrange));
			txtCellLunar.setTextColor(resources.getColor(R.color.color_calendar_outrange));
		}else if(isFestival){
			txtCellLunar.setTextColor(resources.getColor(R.color.color_calendar_festival));
		}else if(isSolarTerm){
			txtCellLunar.setTextColor(resources.getColor(R.color.color_calendar_solarterm));
		}
		if (position % 8 == 1 || position % 8 == 7){
			rootView.setBackgroundResource(R.drawable.selector_calendar_weekend);
		}
		if (date.isToday()){
			ImageView imgCellHint = (ImageView) rootView.findViewById(R.id.imgCellHint);
			imgCellHint.setBackgroundResource(R.drawable.img_hint_today);
			rootView.setBackgroundResource(R.drawable.shape_calendar_cell_today);
		}
		
		// store date into tag
		rootView.setTag(date);
		
		return rootView;
	}

}

