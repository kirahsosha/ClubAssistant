package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;

public class timeSelect1 extends Activity {
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "refreshtimetag.php";
	
	final static int REQUEST=10;
	
	private TextView timeselect_1_back;
	private ListView timeselect_1_timeList;
	private Button timeselect_1_buttonFilter;
	
	public Bundle bundle_inf = new Bundle();
	public Bundle bundle_back = new Bundle();
	
	String AID;
	String UserId;
	String clubName;
	String timeResult;
	String newTagJson;
	String result = "";
	
	String ATID[] = new String[100];
	String StartTime[] = new String[100];
	String EndTime[] = new String[100];
	String TimeTag[] = new String[100];
	int timeNum = 0;
	int ifChecked[] = new int[100];
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timeselect_1);
        
        Bundle bundle = this.getIntent().getExtras();
        AID  = bundle.getString("AID");
        UserId = bundle.getString("UserId");
        clubName = bundle.getString("clubName");
        timeResult = bundle.getString("result");
        
        findAllView();

        SimpleAdapter adapter = new SimpleAdapter(this,showTime(),R.layout.clubactivityinf_list,
                new String[]{"clubactivityinf_list_timeTest",
        					 "clubactivityinf_list_check",},
                new int[]{R.id.clubactivityinf_list_timeTest,
        				  R.id.clubactivityinf_list_check,});
        timeselect_1_timeList.setAdapter(adapter);
	}
	
	private void findAllView(){
		timeselect_1_back = (TextView) findViewById(R.id.timeselect_1_back);
		timeselect_1_back.setOnClickListener(click_timeselect_1_back);
		
		timeselect_1_buttonFilter = (Button) findViewById(R.id.timeselect_1_buttonFilter);
		timeselect_1_buttonFilter.setOnClickListener(click_timeselect_1_buttonFilter);
		
		timeselect_1_timeList = (ListView) findViewById(R.id.timeselect_1_timeList);
		timeselect_1_timeList.setOnItemClickListener(click_timeselect_1_timeList);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("AID", AID);
		bundle_inf.putString("clubName", clubName);
		bundle_inf.putString("timeResult", timeResult);
		
		bundle_back.putString("UserId", UserId);
		bundle_back.putString("AID", AID);
		bundle_back.putString("clubName", clubName);
	}
	
	OnClickListener click_timeselect_1_back = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(timeSelect1.this , clubActivityInf.class);
    		it.putExtras(bundle_back);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnClickListener click_timeselect_1_buttonFilter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		setData();
    		refreshTimeTag();
    		Intent it = new Intent(timeSelect1.this , clubActivityInf.class);
    		it.putExtras(bundle_back);
    		startActivityForResult(it,REQUEST);
    	}
    };
    
    OnItemClickListener click_timeselect_1_timeList = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		TextView check = (TextView) view.findViewById(R.id.clubactivityinf_list_check);
    		if(position == 0)	//������ʱ��
    		{
    			Intent it = new Intent(timeSelect1.this , setNewSelectTime.class);
    			it.putExtras(bundle_inf);
    	    	if (it != null){
    				startActivityForResult(it,REQUEST);
    			}
    		}
    		else	//check
    		{
    			if(ifChecked[position] == 1)
    			{
    				check.setText(" ");
    				ifChecked[position] = 0;
    			}
    			else
    			{
    				check.setText("��");
    				ifChecked[position] = 1;
    			}
    		}
		}
    };
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    private List<Map<String,Object>> showTime()
    {
    	try
    	{
    		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    		
			JSONArray jsonArray = new JSONArray(timeResult);
			//������ʱ��ѡ��
			Map<String,Object> mapnew = new HashMap<String,Object>();
	    	mapnew.put("clubactivityinf_list_timeTest" , "������ʱ��");
	    	mapnew.put("clubactivityinf_list_check" , " ");
	    	list.add(mapnew);
	    	Log.v(TAG, "mapnew");
	    	Log.v(TAG, "i = " + jsonArray.length());
    		for(int i = 1 ; i <= jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject2 = jsonArray.optJSONObject(i - 1);
    			Log.v(TAG, "JSONObject jsonObject2 = jsonArray.optJSONObject(i);");
    			ATID[i] = jsonObject2.optString("ATID");
    			Log.v(TAG, "ATID = " + ATID[i]);
    			StartTime[i] = jsonObject2.optString("StartTime");
    			Log.v(TAG, "StartTime = " + StartTime[i]);
				EndTime[i] = jsonObject2.optString("EndTime");
				Log.v(TAG, "EndTime = " + EndTime[i]);
				TimeTag[i] = jsonObject2.optString("TimeTag");
				Log.v(TAG, "TimeTag = " + TimeTag[i]);
				
				Map<String,Object> map = new HashMap<String,Object>();
		    	map.put("clubactivityinf_list_timeTest" , StartTime[i] + " - " + EndTime[i]);
		    	map.put("clubactivityinf_list_check" , " ");
		    	list.add(map);
		    	Log.v(TAG, "map");
		    	ifChecked[i] = 0;
		    	Log.v(TAG, "ifChecked[i] = 0;");
    		}
    		Log.v(TAG, "date = " + StartTime[1].substring(0 , 10));
    		bundle_inf.putString("dateString", StartTime[1].substring(0 , 10));
    		timeNum = jsonArray.length();
    		Log.v(TAG, "timeNum = " + timeNum);
    		return list;
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
			return null;
		}
    }
    
    private void setData()
    {
    	newTagJson = "[";
    	int t = 0;
    	int TimeTagInt = 0;
    	for(int i = 1 ; i <= timeNum ; i++)
    	{
    		TimeTagInt = Integer.parseInt(TimeTag[i]);
    		if(ifChecked[i] == 1)
    		{
    			TimeTagInt++;
    			t++;
    			if(t != 0)
    			{
    				newTagJson += ",";
    			}
    			newTagJson += "{\"ATID\":\"" + ATID[i] + "\",\"StartTime\":\"" + StartTime[i] + "\",\"EndTime\":\"" + EndTime[i] + "\",\"TimeTag\":\"" + TimeTagInt + "\"}";
    		}
    	}
    	newTagJson += "]";
    }
    
    public void refreshTimeTag()
    {
    	Log.v(TAG,"111");
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
    			Log.v(TAG,"222");
				// TODO Auto-generated method stub
				try
				{
					Log.v(TAG,"333");
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("newTagJson", newTagJson));
		            params.add(new BasicNameValuePair("AID", AID));
		            Log.v(TAG,"444");
		            HttpPost httpRequest = new HttpPost(url);
		            Log.v(TAG,"555");
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            Log.v(TAG,"666");
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            Log.v(TAG,"777");
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	Log.v(TAG,"888");
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}