package com.kirahsosha.clubassistant;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kirahsosha.Connection.connectIP;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class newActivityTime extends Activity {
	
	private static final String TAG = "jby";
	private static final String url = connectIP.IP + "getenabletime.php";
	private static final String urlC = connectIP.IP + "createactivity.php";
	
	final static int REQUEST=10;
	
	private TextView newactivitytime_enableTime;
	private TextView newactivitytime_date;
	private Button newactivitytime_buttonBack;
	private Button newactivitytime_buttonEnter;
	private Button newactivitytime_buttonNewTime;
	private ListView newactivitytime_newTimeList;
	
	String CID;
	String UserId;
	String ActivityName;
	String ActivityNum;
	String ActivityPlace;
	int year , month , day;
	String clubName;
	String clubType;
	String clubSubjection;
	String clubNum;
	String QQ;
	String WeiXin;
	String timeJson = "";
	String newTimeJson = "";
	
	public Bundle bundle_inf = new Bundle();
	public Bundle bundle_new = new Bundle();
	public Bundle bundle_change = new Bundle();
	
	String result = "";
	String resultC = "";
	String enableStartTime = "";
	String enableEndTime = "";
	String enableTime = "";
	String stClub = "";
	String newStartTime[] = new String[100];
	String newEndTime[] = new String[100];
	int timeNum = 0;
	
	int startHour;
	int startMinute;
	int endHour;
	int endMinute;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newactivitytime);
        Bundle bundle = this.getIntent().getExtras();
        CID  = bundle.getString("CID");
        UserId = bundle.getString("UserId");
        year = bundle.getInt("year");
        month = bundle.getInt("month");
        day = bundle.getInt("day");
        ActivityName = bundle.getString("ActivityName");
        ActivityNum = bundle.getString("ActivityNum");
        ActivityPlace = bundle.getString("ActivityPlace");
        clubName  = bundle.getString("clubName");
        clubType  = bundle.getString("clubType");
        clubSubjection  = bundle.getString("clubSubjection");
        clubNum  = bundle.getString("clubNum");
        QQ  = bundle.getString("QQ");
        WeiXin  = bundle.getString("WeiXin");
        stClub  = bundle.getString("stClub");
        timeJson  = bundle.getString("timeJson");	//�Ѿ���jsonͷ�Ĵ�
        newTimeJson = timeJson + "]";
        Log.v(TAG , "newTimeJson = " + newTimeJson);
        
        findAllView();
        
        newactivitytime_date.setText(showDate(year , month , day));
        
        getEnableTime();
        showEnableTime();
        
        SimpleAdapter adapter = new SimpleAdapter(this,showData(),R.layout.newactivitytime_list,
                new String[]{"newactivitytime_list_startTime",
							 "newactivitytime_list_endTime",},
                new int[]{
						  R.id.newactivitytime_list_startTime,
						  R.id.newactivitytime_list_endTime,});
        newactivitytime_newTimeList.setAdapter(adapter);
	}
	
	private void findAllView(){
		newactivitytime_enableTime = (TextView) findViewById(R.id.newactivitytime_enableTime);
		newactivitytime_date = (TextView) findViewById(R.id.newactivitytime_date);
		
		newactivitytime_buttonBack = (Button) findViewById(R.id.newactivitytime_buttonBack);
		newactivitytime_buttonBack.setOnClickListener(click_newactivitytime_buttonBack);
		
		newactivitytime_buttonEnter = (Button) findViewById(R.id.newactivitytime_buttonEnter);
		newactivitytime_buttonEnter.setOnClickListener(click_newactivitytime_buttonEnter);
		
		newactivitytime_buttonNewTime = (Button) findViewById(R.id.newactivitytime_buttonNewTime);
		newactivitytime_buttonNewTime.setOnClickListener(click_newactivitytime_buttonNewTime);
		
		newactivitytime_newTimeList = (ListView) findViewById(R.id.newactivitytime_newTimeList);
		newactivitytime_newTimeList.setOnItemClickListener(click_newactivitytime_newTimeList);
		
		bundle_inf.putString("UserId", UserId);
		bundle_inf.putString("CID", CID);
		bundle_inf.putString("clubName", clubName);
		bundle_inf.putString("clubType", clubType);
		bundle_inf.putString("clubSubjection", clubSubjection);
		bundle_inf.putString("clubNum", clubNum);
		bundle_inf.putString("QQ", QQ);
		bundle_inf.putString("WeiXin", WeiXin);
		bundle_inf.putString("stClub", stClub);
		
		bundle_new.putString("UserId", UserId);
		bundle_new.putString("CID", CID);
		bundle_new.putInt("year", year);
		bundle_new.putInt("month", month);
		bundle_new.putInt("day", day);
		bundle_new.putString("ActivityName", ActivityName);
		bundle_new.putString("ActivityNum", ActivityNum);
		bundle_new.putString("ActivityPlace", ActivityPlace);
		bundle_new.putString("clubName", clubName);
		bundle_new.putString("clubType", clubType);
		bundle_new.putString("clubSubjection", clubSubjection);
		bundle_new.putString("clubNum", clubNum);
		bundle_new.putString("QQ", QQ);
		bundle_new.putString("WeiXin", WeiXin);
		bundle_new.putString("stClub", stClub);
		bundle_new.putString("timeJson", timeJson);
		
		bundle_change.putString("UserId", UserId);
		bundle_change.putString("CID", CID);
		bundle_change.putInt("year", year);
		bundle_change.putInt("month", month);
		bundle_change.putInt("day", day);
		bundle_change.putString("ActivityName", ActivityName);
		bundle_change.putString("ActivityNum", ActivityNum);
		bundle_change.putString("ActivityPlace", ActivityPlace);
		bundle_change.putString("clubName", clubName);
		bundle_change.putString("clubType", clubType);
		bundle_change.putString("clubSubjection", clubSubjection);
		bundle_change.putString("clubNum", clubNum);
		bundle_change.putString("QQ", QQ);
		bundle_change.putString("WeiXin", WeiXin);
		bundle_change.putString("stClub", stClub);
		bundle_change.putString("timeJson", timeJson);
	}
	
	OnClickListener click_newactivitytime_buttonBack = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent in = getIntent();
    		setResult(RESULT_OK,in);
    		finish();
    	}
    };
    
    OnClickListener click_newactivitytime_buttonEnter = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		int IfCreate = 3;	//ifCreateActivity();
    		Log.v(TAG , Integer.toString(IfCreate));
    		switch (IfCreate)
    		{
    		case 0:
    			Toast.makeText(newActivityTime.this, "δ֪����",Toast.LENGTH_LONG ).show();
    			break;
    		case 1:
    			Toast.makeText(newActivityTime.this, "�����ʱ������ڿ�ʼʱ��֮��",Toast.LENGTH_LONG ).show();
    			break;
    		case 2:
    			Toast.makeText(newActivityTime.this, "�ʱ�������������ʱ�䷶Χ֮�ڣ�",Toast.LENGTH_LONG ).show();
    			break;
    		case 3:
    			createActivity();
        		if(resultC.compareTo("1") == 0)
                {
                	Log.v(TAG,"Register Success");
                	Toast.makeText(newActivityTime.this, "�»�����ɹ�", Toast.LENGTH_LONG ).show();
                	Intent it = new Intent(newActivityTime.this , clubInf.class);
                	it.putExtras(bundle_inf);
        	    	if (it != null){
        				startActivityForResult(it,REQUEST);
        			}
                }
                else
                {
                	Toast.makeText(newActivityTime.this, "Error:" + resultC, Toast.LENGTH_LONG ).show();
                }
    		}
    	}
    };
    
    OnClickListener click_newactivitytime_buttonNewTime = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		Intent it = new Intent(newActivityTime.this , setNewTime.class);
        	it.putExtras(bundle_new);
	    	if (it != null){
				startActivityForResult(it,REQUEST);
			}
    	}
    };
    
    OnItemClickListener click_newactivitytime_newTimeList = new OnItemClickListener(){
    	@Override
    	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
    		
			bundle_change.putString("newStartTime", newStartTime[position]);
			bundle_change.putString("newEndTime", newEndTime[position]);
    		Intent it = new Intent(newActivityTime.this, changeNewTime.class);	//�޸�ʱ��Ľ���
    		it.putExtras(bundle_change);
    		if (it != null){
				startActivityForResult(it,REQUEST);
			}
		}
    };
    
    private void getEnableTime()
    {
    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
		            params.add(new BasicNameValuePair("CID", CID));
		            params.add(new BasicNameValuePair("year", Integer.toString(year)));
		            params.add(new BasicNameValuePair("month", Integer.toString(month)));
		            params.add(new BasicNameValuePair("day", Integer.toString(day)));
		            HttpPost httpRequest = new HttpPost(url);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	result = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+result);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void showEnableTime()
    {
    	try
		{
			JSONObject jsonObject = new JSONObject(result); 
			JSONArray jsonArray = jsonObject.getJSONArray("enableTime");
			
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				enableStartTime = jsonObject2.optString("StartTime");
				enableEndTime = jsonObject2.optString("EndTime");
				enableTime += enableStartTime + " - " + enableEndTime + "\n";
			}
			newactivitytime_enableTime.setText(enableTime);
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
    }
    
    //�ж��Ƿ񴴽��»
    //����ֵ
    //0 - NULL
    //1 - ����ʱ�䲻�ڿ�ʼʱ��֮��
    //2 - �ʱ�䲻��������Χ֮��
    //3 - ���Դ���
    private int ifCreateActivity()
    {
    	int iStartTime , iEndTime , iEnableStartTime , iEnableEndTime;
    	//startHour = newactivitytime_startTimePicker.getCurrentHour();
    	//startMinute = newactivitytime_startTimePicker.getCurrentMinute();
    	//endHour = newactivitytime_endTimePicker.getCurrentHour();
    	//endMinute = newactivitytime_endTimePicker.getCurrentMinute();
    	
    	iStartTime = timeTax(startHour , startMinute);
    	iEndTime = timeTax(endHour , endMinute);
    	//�жϽ���ʱ���Ƿ��ڿ�ʼʱ��֮��
    	if(iEndTime <= iStartTime)
    	{
    		return 1;
    	}
    	
    	try
		{
			JSONObject jsonObject = new JSONObject(result);
			JSONArray jsonArray = jsonObject.getJSONArray("enableTime");
			
			for(int i = 0 ; i < jsonArray.length() ; i++)
			{
				JSONObject jsonObject2 = jsonArray.optJSONObject(i);
				enableStartTime = jsonObject2.optString("StartTime");
				enableEndTime = jsonObject2.optString("EndTime");
				int enableStartHour = Integer.parseInt(enableStartTime.substring(0 , 2));
				int enableStartMinute = Integer.parseInt(enableStartTime.substring(3 , 5));
				int enableEndHour = Integer.parseInt(enableEndTime.substring(0 , 2));
				int enableEndMinute = Integer.parseInt(enableEndTime.substring(3 , 5));
				iEnableStartTime = timeTax(enableStartHour , enableStartMinute);
				iEnableEndTime = timeTax(enableEndHour , enableEndMinute);
				//�ж�ʱ���Ƿ�������ʱ���֮��
				if(iStartTime > iEnableStartTime && iEndTime < iEnableEndTime)
				{
					return 3;
				}
			}
			return 2;
		}
		catch (Exception e)
		{
			Log.v(TAG, e.toString());
		}
    	return 0;
    }
    //ת��������
    private int timeTax(int h , int m)
    {
    	return h * 60 + m;
    }
    
    private void createActivity()
    {

    	Runnable r1 = new Runnable()
    	{
    		@Override
			public void run()
    		{
				// TODO Auto-generated method stub
				try
				{
					List<NameValuePair> params = new ArrayList<NameValuePair>();
					params.add(new BasicNameValuePair("CID", CID));
					params.add(new BasicNameValuePair("UserId", UserId));
		            params.add(new BasicNameValuePair("year", Integer.toString(year)));
		            params.add(new BasicNameValuePair("month", Integer.toString(month)));
		            params.add(new BasicNameValuePair("day", Integer.toString(day)));
		            //params.add(new BasicNameValuePair("startHour", Integer.toString(startHour)));
		            //params.add(new BasicNameValuePair("startMinute", Integer.toString(startMinute)));
		            //params.add(new BasicNameValuePair("endHour", Integer.toString(endHour)));
		            //params.add(new BasicNameValuePair("endMinute", Integer.toString(endMinute)));
		            params.add(new BasicNameValuePair("ActivityName", ActivityName));
		            params.add(new BasicNameValuePair("ActivityNum", ActivityNum));
		            params.add(new BasicNameValuePair("ActivityPlace", ActivityPlace));
		            params.add(new BasicNameValuePair("newTimeJson", newTimeJson));
		            HttpPost httpRequest = new HttpPost(urlC);
		            HttpEntity httpEntity = new UrlEncodedFormEntity(params,"utf-8");
		            httpRequest.setEntity(httpEntity);
		            HttpClient httpClient = new DefaultHttpClient();
		            /*HttpResponse httpResponse = null;
		            try {
		            	httpResponse = httpClient.execute(httpRequest);
		            } catch (Exception e) {
		            	Log.v(TAG, e.toString());
		            }*/
		            HttpResponse httpResponse = httpClient.execute(httpRequest);
		            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK)
		            {
		            	resultC = EntityUtils.toString(httpResponse.getEntity());
		                Log.v(TAG,"result = "+resultC);
		            }
		            else
		            {
		            	Log.v(TAG,"999");
		            }
				}
				catch (UnsupportedEncodingException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (ClientProtocolException e)
		        {
		        	// TODO Auto-generated catch block
		            e.printStackTrace();
		        }
		        catch (IOException e)
		        {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }
    		}
    	};
    	Thread t1 = new Thread(r1);
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private List<Map<String,Object>> showData()
    {
    	try
    	{
    		List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
    		
    		JSONArray jsonArray = new JSONArray(newTimeJson);
    		for(int i = 0 ; i < jsonArray.length() ; i++)
    		{
    			JSONObject jsonObject = jsonArray.optJSONObject(i);
    			newStartTime[i] = jsonObject.optString("start");
				newEndTime[i] = jsonObject.optString("end");
				
				Map<String,Object> map = new HashMap<String,Object>();
		    	map.put("newactivitytime_list_startTime" , newStartTime[i]);
		    	map.put("newactivitytime_list_endTime" , newEndTime[i]);
		    	list.add(map);
    		}
    		timeNum = jsonArray.length();
    		return list;
    	}
    	catch (Exception e)
		{
			Log.v(TAG, e.toString());
			return null;
		}
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	//requestcode ���𷢳���������
    	if(requestCode==REQUEST){//�ڶ���ҳ�淵����������
    	//resultcode ���ֽ���Ƿ�������������
	    	if(resultCode==RESULT_OK){
	    	//�����ɹ�
	    	}
	    	else if(resultCode==RESULT_CANCELED){
	    	//����ʧ��
	    	}
    	}
    };
    
    String showDate(int year2 , int month2 , int day2)
    {
    	String date = year2 + "";
    	if(month2 > 10)
    	{
    		date = date + "-" + month2;
    	}
    	else
    	{
    		date = date + "-0" + month2;
    	}
    	
    	if(day2 > 10)
    	{
    		date = date + "-" + day2;
    	}
    	else
    	{
    		date = date + "-0" + day2;
    	}
    	return date;
    }
}