package com.kirahsosha.Connection;

public class connectIP {
	//public static final String IP = "http://10.202.13.108:80/ClubAssistantServer/activity/";
	//public static final String IP = "http://192.168.1.103:80/ClubAssistantServer/activity/";
	public static final String IP = "http://172.20.10.12:80/ClubAssistantServer/activity/";
}